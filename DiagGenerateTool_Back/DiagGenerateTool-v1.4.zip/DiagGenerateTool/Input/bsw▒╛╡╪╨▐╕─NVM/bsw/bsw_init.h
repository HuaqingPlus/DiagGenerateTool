#ifndef BSW_INIT_H
#define BSW_INIT_H

    /*----------------------------------------------------------------------------
    ** Types declaration
    */
      /*  #ifndef LIB_TYPES_H                           */
      /*      #error "lib_Types.h should be included"   */
      /*  #endif                                        */

    /*----------------------------------------------------------------------------
    ** Imports
    */

    /*----------------------------------------------------------------------------
    ** Define constants
    */

    /*----------------------------------------------------------------------------
    ** Public functions declaration
    */

    extern Bsw_Init();

#endif
