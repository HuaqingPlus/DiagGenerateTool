
#ifndef BSW_TASK_H
#define BSW_TASK_H

    /*----------------------------------------------------------------------------
    ** Types declaration
    */
      /*  #ifndef LIB_TYPES_H                           */
      /*      #error "lib_Types.h should be included"   */
      /*  #endif                                        */

    /*----------------------------------------------------------------------------
    ** Imports
    */

    /*----------------------------------------------------------------------------
    ** Define constants
    */

    /*----------------------------------------------------------------------------
    ** Public functions declaration
    */
	extern void Bsw_task_5ms(void * para);
    extern void Bsw_task_50ms(void * para);

#endif
