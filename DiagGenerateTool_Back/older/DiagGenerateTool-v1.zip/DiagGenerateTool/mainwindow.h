﻿#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QtDebug>
#include <QFileDialog>
#include <QDir>
#include <QAbstractItemModel>
#include <QStandardItemModel>
#include <QStandardItem>
#include <QTextCodec>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

#define DID_READ        ((uint8)1)
#define DID_WRITE       ((uint8)2)
#define DID_IOCTRL      ((uint8)4)

#define DCM_DIDMGR_OPCLS_READ_SYNC  ((uint8)1)
#define DCM_DIDMGR_OPCLS_READ_ASYNC ((uint8)2)

#define DCM_DIDMGR_OPCLS_WRITE_SYNC  ((uint8)1)
#define DCM_DIDMGR_OPCLS_WRITE_ASYNC ((uint8)2)

//数据类型定义
typedef uint8_t uint8;
typedef int8_t sint8;
typedef uint16_t uint16;
typedef uint32_t uint32;

typedef struct
{
  uint8 Length;       //Write Data Length
  uint8 OpInfoRef;    //引用DidOpInfo的index
  uint8 Operations;   //Read | Write | IO
}Dcm_DspDidInfoType;

typedef struct
{
  uint8 State_Ref;      //引用Dcm_DsdStateRefo的index
  uint8 SignalInfo_Ref; //都是0
  uint8 CallTypes;      //都是SYNC（同步）
}Dcm_DspDidOpInfoType;

//内部数据
typedef struct
{
    uint8 Sid;
    uint8 StateRef;
}State_SID_Ref_Type;

typedef struct
{
    uint16 Did;
    uint8 Operation;
    uint8 DataLen;
}S_DID_Infos_Type;

typedef struct
{
    uint16 Did;
    uint8 Length;
    uint8 OpInfoRef;
    uint8 Operation;
    uint8 State_Ref;
    uint8 SIgnalInfo_Ref;
    uint8 CallTypes;
}S_DID_Configs_Type;


//class 定义
class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    void MainWindow_Init(void);

public:
    void TableView_UpdateDid(void);
    void TableView_UpdateRid(void);

public slots:
    void Slot_TreeView_Clicled(QModelIndex index);
    void Slot_TableConfig_customContextMenuRequested(const QPoint &pos);
    void Slot_AddDID(bool checked);
    void Slot_DelDID(bool checked);
    void Slot_Generate(bool checked);
    void Slot_UpdateDidInfos(QStandardItem *item);

private:
    Ui::MainWindow *ui;
};
#endif // MAINWINDOW_H


