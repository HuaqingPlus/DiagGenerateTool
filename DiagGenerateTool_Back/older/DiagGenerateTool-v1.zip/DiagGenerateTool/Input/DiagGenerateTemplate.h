#ifndef __DIAGGENERATETEPMLATE_H__
#define __DIAGGENERATETEPMLATE_H__

/*********************************************************************/
/*                       DiagTool.Generate Start                     */
/*********************************************************************/


/* PID Define */
#define Pid_A1A1           				((uint16)0xA1A1)
#define Pid_F1B1                    	((uint16)0xF1B1)             

#ifndef DCM_TABLE_SUPPORTED_DID
#define DCM_TABLE_SUPPORTED_DID \
/* User Define */       Pid_A1A1, 	   \
/* User Define */	    Pid_F1B1,  
#endif

#ifndef DCM_TABLE_DID_INFO
#define DCM_TABLE_DID_INFO \
{10  ,0,  3},\
{1   ,2,  4},
#endif

#ifndef DCM_TABLE_DID_OPERATION_INFO
#define DCM_TABLE_DID_OPERATION_INFO \
{0x02 ,0x00 ,0x01 },\
{0x03 ,0x00 ,0x01 },\
{0x04 ,0x00 ,0x09 },
#endif

#ifndef PROD_SPEC_DIAG_PID_TABLE
#define PROD_SPEC_DIAG_PID_TABLE \
/*0xA1A1*/	{Pid_A1A1		  			   ,fdiag_app_A1A1_Read		  						  },\

#endif

#ifndef PROD_SPEC_DIAG_WRITE_PID_TABLE
#define PROD_SPEC_DIAG_WRITE_PID_TABLE \
/*0xA1A1*/	{Pid_A1A1		               ,fdiag_app_A1A1_Write		  					  },\

#endif

#ifndef PROD_SPEC_DIAG_IOCTL_BY_ID_FOR_EOL_TABLE
#define PROD_SPEC_DIAG_IOCTL_BY_ID_FOR_EOL_TABLE \
{	/*0xF1B1*/	\
	Pid_F1B1,\
	RETURN_CONTROL_ECU|FREEZE_CURRENT_STATE|RESET_TO_DEFAULT|SHORT_TERM_ADJUST,\
	DID_0x2FDID_SIZE_2,\
	NULL,\
	fdiag_app_F1B1_IOC,\
	NULL,\
},	\
#endif

#ifndef DCM_TABLE_SUPPORTED_RID
#define DCM_TABLE_SUPPORTED_RID \
/* User Define */   0x0202,\
/* User Define */   0x0203,\
/* User Define */   0xFF01,\
/* User Define */   0xF103,\
/* User Define */   0xF104,\
/* User Define */   0xF11E
#endif

#ifndef DCM_TABLE_RID_INFO
#define DCM_TABLE_RID_INFO \
{0x0, 0x5, 0x0F},\
{0x1, 0x5, 0x0F},\
{0x2, 0x5, 0x0F},\
{0x3, 0x5, 0x0F},\
{0x4, 0x5, 0x0F},\
{0x5, 0x5, 0x0F}
#endif

#ifndef DCM_TABLE_RID_SIGNAL_INFO
#define DCM_TABLE_RID_SIGNAL_INFO \
{ 0, 0x0, 0xF, 0x0F},\
{ 0, 0x0, 0xF, 0x0F},\
{ 0, 0x0, 0xF, 0x0F},\
{ 0, 0x0, 0xF, 0x0F},\
{ 0, 0x0, 0xF, 0x0F},\
{ 0, 0x1, 0xF, 0x0F} 
#endif


/****************************************************************************
Function Name     : fdiag_app_A1A1_Read

Description       : This function is used to read DID A1A1

Invocation        : dg_app

Parameters        : None

Return Value      : UINT8

Critical Section  : None

******************************************************************************/
static uint8 fdiag_app_A1A1_Read(uint8 Buff[])
{
	uint8 fl_ret = 0;
	return fl_ret;
}

/****************************************************************************
Function Name     : fdiag_app_A1A1_Read

Description       : This function is used to read DID A1A1

Invocation        : dg_app

Parameters        : None

Return Value      : UINT8

Critical Section  : None

******************************************************************************/
static uint8 fdiag_app_A1A1_Write(uint8 Buff[])
{
	uint8 fl_ret = 0;
	return fl_ret;
}



/*********************************************************************/
/*                       DiagTool.Generate Stop                      */
/*********************************************************************/


/****************************************************************************
Function Name     : fdiag_app_F1B1_IOC
Description       : control
Invocation        :
Parameters        : None
Return Value      : UINT8
Critical Section  : None
******************************************************************************/
static uint8 fdiag_app_F1B1_IOC(uint8 fl_ctrl_parameter, uint8 *fl_get_ctrl_value)
{
	// DCM_IOC_Type DID_Value;
	// uint8 fl_get_ctrl_status;
    // fl_get_ctrl_status = 0;
    // if((fl_ctrl_parameter == SHORT_TERM_ADJUST) || (fl_ctrl_parameter == RETURN_CONTROL_ECU))
    // {
	// 	switch(fl_ctrl_parameter)
	// 	{
	// 		case RETURN_CONTROL_ECU:
	// 		{

    //             DID_Value.DID_IOC_Number = 0xF1B1;
	// 			DID_Value.DID_IOC_Parament = 0x00;
	// 			//Rte_Write_ppSR_TIDcm_DID_IOC_DCM_IOC_Value(&DID_Value);

	// 		}break;
	// 		case SHORT_TERM_ADJUST:
	// 		{
	// 			DID_Value.DID_IOC_Number = 0xF1B1;
	// 			DID_Value.DID_IOC_Parament = 0x03;
	// 			DID_Value.DID_IOC_State[0] = fl_get_ctrl_value[0];
	// 			DID_Value.DID_IOC_State[1] = fl_get_ctrl_value[1];
	// 			DID_Value.DID_IOC_State[2] = fl_get_ctrl_value[2];
	// 			DID_Value.DID_IOC_State[3] = fl_get_ctrl_value[3];
	// 			//Rte_Write_ppSR_TIDcm_DID_IOC_DCM_IOC_Value(&DID_Value);
				
	// 			fl_ctrl_parameter = 0x03;
	// 			fl_get_ctrl_value[0] = DID_Value.DID_IOC_State[0];
	// 			fl_get_ctrl_value[1] = DID_Value.DID_IOC_State[1];
	// 			fl_get_ctrl_value[2] = DID_Value.DID_IOC_State[2];
	// 			fl_get_ctrl_value[3] = DID_Value.DID_IOC_State[3];
	// 			fl_get_ctrl_status = 0;
	// 		}break;
	// 		default:
	// 		{
	// 			fl_get_ctrl_status = kwp2k_diag_NrcSubfunctionNotSupported;
	// 		}break;
	// 	}
    // }
	// else
	// {
	// 	fl_get_ctrl_status = kwp2k_diag_NrcInvalidFormat;
	// }
    return(0);
}

#endif
