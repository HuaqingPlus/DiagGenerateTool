﻿#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    MainWindow_Init();
    connect(ui->But_Generate, &QPushButton::clicked, this, &MainWindow::Slot_Generate);
//    connect(ui->Table_Config, &QTableView::c);
//    connect(set);
}

MainWindow::~MainWindow()
{
    delete ui;
}


//DID配置
//记录界面中的配置信息
QList<S_DID_Infos_Type> List_DID_Infos_User;
//根据配置信息，再扩展其他需要的配置信息
QList<S_DID_Configs_Type> List_DID_Configs;

//记录所有的DID值，
//用于生成DID_XXXX和DCM_TABLE_SUPPORTED_DID
QList<uint16> List_Did;

//记录DID 操作，数据长度等信息
//用于生成DCM_TABLE_DID_INFO
QList<Dcm_DspDidInfoType> List_DidInfo;

//记录State_Ref及其他,
//用于生成DCM_TABLE_DID_OPERATION_INFO
QList<Dcm_DspDidOpInfoType> List_DidOpInfo;


//RID配置
QList<uint16> List_Rid;



/* QTreeView的Item*/
QStandardItemModel Stand_Model;
QStandardItem* Item_Diag[2];
QStandardItem* Item_DcmSub[3];
//右键菜单
QAction* Ptr_Action_AddDID;
QAction* Ptr_Action_DelDID;
QMenu* Ptr_Menu;

/* QTabView的Item*/
QStandardItemModel StdModel_Did;
QStandardItemModel StdModel_Rid;
QList<QStandardItem*> List_DidTable;
QList<QStandardItem*> List_RidTable;
//QStandardItem* Item_DcmSub[3];

//配置数据
const State_SID_Ref_Type State_SID_Table[] = \
{\
    {0x22, 2},\
    {0x2E, 3},\
    {0x2F, 4},\
    {0x31, 5}
};


void MainWindow::MainWindow_Init(void)
{
//    QString Str_Open_Path = QString("./../DiagGenerateTool/Input");
//    QString Str_File_Template = QFileDialog::getOpenFileName(this, "Open Template", \
//                                                             QDir::toNativeSeparators(Str_Open_Path), "*.*");
    QFile File_DiagConfig("./../File_DiagConfig/Input/DiagGenerateTemplate.h");


    //设置QTreeview的属性
    Item_Diag[0] = new QStandardItem("DCM Config");
    Item_Diag[1] = new QStandardItem("DEM Config");
    Item_DcmSub[0] = new QStandardItem("DID Table");
    Item_DcmSub[1] = new QStandardItem("RID Table");

    Item_Diag[0]->insertRow(0, Item_DcmSub[0]);
    Item_Diag[0]->insertRow(1, Item_DcmSub[1]);
    Stand_Model.insertRow(0, Item_Diag[0]);
    Stand_Model.insertRow(1, Item_Diag[1]);
    //禁止编辑
    Item_Diag[0]->setEditable(false);
    Item_Diag[1]->setEditable(false);
    Item_DcmSub[0]->setEditable(false);
    Item_DcmSub[1]->setEditable(false);

    ui->Tree_Config->setModel(&Stand_Model);
    //隐藏header
    ui->Tree_Config->setHeaderHidden(true);

    //设置QTabView的属性
    connect(ui->Tree_Config, &QTreeView::clicked, this, &MainWindow::Slot_TreeView_Clicled);

    //增加右键菜单
    Ptr_Menu = new QMenu(ui->Table_Config);
    Ptr_Action_AddDID = Ptr_Menu->addAction("Add Did");
    Ptr_Action_DelDID = Ptr_Menu->addAction("Delete Did");

    ui->Table_Config->addAction(Ptr_Action_AddDID);
    ui->Table_Config->addAction(Ptr_Action_DelDID);

    connect(Ptr_Action_AddDID, &QAction::triggered, this, &MainWindow::Slot_AddDID);
    connect(Ptr_Action_DelDID, &QAction::triggered, this, &MainWindow::Slot_DelDID);

    ui->Table_Config->setContextMenuPolicy(Qt::CustomContextMenu);//必须设置
    connect(ui->Table_Config, &QTableView::customContextMenuRequested, this, &MainWindow::Slot_TableConfig_customContextMenuRequested);
    connect(&StdModel_Did, &QStandardItemModel::itemChanged, this, &MainWindow::Slot_UpdateDidInfos);

}

void MainWindow::Slot_TreeView_Clicled(QModelIndex index)
{
    QString Str_ItemName = ui->Tree_Config->model()->itemData(index).values().at(0).toString();
    if(Str_ItemName == "DID Table")
    {
        TableView_UpdateDid();
    }
    else if(Str_ItemName == "RID Table")
    {
        TableView_UpdateRid();
    }
    else
    {
        /* ToBeDefine */
    }
}



void MainWindow::TableView_UpdateDid(void)
{
    QStringList Strlist_Header;
    QStringList Strlist_HeaderTip;
    QStandardItem* TempItem;
    QList<uint16> List_Did_Temp;
    //QStandardItem* Model_Header[4];
    //QList<QStandardItem*> List_StdItem_Temp;

    //设置表列数
    StdModel_Did.setColumnCount(4);

    List_Did_Temp = List_Did;

    //test
    //List_Did << 0xA1A1 << 0xB1B1 << 0xC1C1;

    List_DidTable.clear();
    StdModel_Did.clear();

    //设置表中第一列
    for(int i = 0; i < List_Did_Temp.count(); i++)
    {
       //QList<QStandardItem*> List_StdItem_Temp;
        TempItem = new QStandardItem(QString::number(List_Did.at(i), 16).toUpper());
        //设置居中对齐
        TempItem->setTextAlignment(Qt::AlignCenter);
        List_DidTable.append(TempItem);

        //List_StdItem_Temp.a
    }
    StdModel_Did.insertColumn(0, List_DidTable);

    //设置表头和ToolTip
    Strlist_Header << "DID" << "READ" << "WRITE" << "DataLen(Byte)" << "IOCTRL";
    Strlist_HeaderTip << "DID" << QString::fromLocal8Bit("配置是否支持Read功能") \
                      << QString::fromLocal8Bit("配置是否支持Write功能") \
                      << QString::fromLocal8Bit("如果配置READ或WRITE 则数据长度应该指定")\
                      << QString::fromLocal8Bit("配置是否支持IOCTRL");

    for(int i = 0; i < Strlist_Header.size(); i++)
    {
        TempItem = new QStandardItem(Strlist_Header.at(i));
        TempItem->setTextAlignment(Qt::AlignCenter);
        TempItem->setToolTip(Strlist_HeaderTip.at(i));
        StdModel_Did.setHorizontalHeaderItem(i,TempItem);
    }

    //设置配置选项为Chekbox
    qDebug() << StdModel_Did.rowCount() << StdModel_Did.columnCount();
    for(int i = 0; i < StdModel_Did.rowCount(); i++)
    {
        for(int j = 1; j < StdModel_Did.columnCount(); j++)
        {
            /* DataLength 不设置CheckBox */
            if(j != 3)
            {
                TempItem = new QStandardItem("");
                TempItem->setCheckable(true);
                /* 禁止编辑 */
                TempItem->setEditable(false);
                StdModel_Did.setItem(i, j, TempItem);
            }
        }
    }

    ui->Table_Config->setModel(&StdModel_Did);
}



void MainWindow::Slot_TableConfig_customContextMenuRequested(const QPoint &pos)
{
    bool Enable_Menu = false;
    QModelIndex index = ui->Table_Config->indexAt(pos);
    qDebug() << "index at : " << index;
    sint8 col = index.row();
    if(col == (-1))
    {
        if(List_Did.isEmpty())
        {
            Enable_Menu = true;
        }
        else
        {
            Enable_Menu = false;
        }
    }
    else
    {
        Enable_Menu = true;
    }
    if(Enable_Menu == true)
    {
        //弹出右键菜单
        Ptr_Menu->exec(QCursor::pos());
    }
}

void MainWindow::Slot_AddDID(bool checked)
{
    qDebug("Add Did");
    List_Did.append(0);
    TableView_UpdateDid();
}

void MainWindow::Slot_DelDID(bool checked)
{
    qDebug("Del Did");
}

void MainWindow::TableView_UpdateRid(void)
{
    List_Rid.clear();
    //test
    List_Rid << 0x5555 << 0x6666 << 0x7777;

    QStandardItem* TempItem;

    List_RidTable.clear();
    StdModel_Rid.clear();
    for(int i = 0; i < List_Rid.count(); i++)
    {
        TempItem = new QStandardItem(QString::number(List_Rid.at(i), 16).toUpper());
        TempItem->setTextAlignment(Qt::AlignCenter);
        List_RidTable.append(TempItem);
    }

    StdModel_Rid.insertColumn(0,List_RidTable);
    ui->Table_Config->setModel(&StdModel_Rid);
}


void MainWindow::Slot_UpdateDidInfos(QStandardItem *item)
{
    qDebug("DataChanged, update...");
    uint8 row = StdModel_Did.rowCount();
    uint8 col = StdModel_Did.columnCount();
    S_DID_Infos_Type S_DidInfos_Temp_User;
    uint8 Did_Operation = 0;
    S_DID_Configs_Type S_DidConfigs_Temp;
    Dcm_DspDidInfoType S_DidInfo_Temp;
#if 0
    //获取界面配置信息
    for(int i = 0; i < row; i ++)
    {

        for(int j = 0; j < col; j++)
        {
            switch(j)
            {
                case (0):/* DID */
                    S_DidInfos_Temp_User.Did = StdModel_Did.item(i, j)->data().toUInt();
                    break;
                case (3):/* Datalen */
                    S_DidInfos_Temp_User.DataLen = StdModel_Did.item(i, j)->data().toUInt();
                    break;
                case (1):/* Read Flag */
                    if(StdModel_Did.item(i, j)->checkState())
                    {
                        Did_Operation |= DID_READ;
                    }
                    break;
                case (2):/* Write Flag */
                    if(StdModel_Did.item(i, j)->checkState())
                    {
                        Did_Operation |= DID_WRITE;
                    }
                    break;
                case (4):/* IoCtrl Flag */
                    if(StdModel_Did.item(i, j)->checkState())
                    {
                        Did_Operation |= DID_IOCTRL;
                    }
                    break;
                default:
                    break;
            }
            S_DidInfos_Temp_User.Operation = Did_Operation;
        }
        List_DID_Infos_User.append(S_DidInfos_Temp_User);
    }

    //根据界面配置，得出DID的配置信息
    for(int i = 0; i < List_DID_Infos_User.count(); i++)
    {
        S_DidConfigs_Temp.Did = List_DID_Infos_User.at(i).Did;
        S_DidConfigs_Temp.Length = List_DID_Infos_User.at(i).DataLen;
        S_DidConfigs_Temp.Operation = List_DID_Infos_User.at(i).Operation;
        S_DidConfigs_Temp.CallTypes = 1;//默认值
        S_DidConfigs_Temp.SIgnalInfo_Ref = 0;//默认值

        uint8 count = sizeof(State_SID_Table) / sizeof(State_SID_Table[0]);
        for(int j = 0; j < count; j++)
        {
            //if()
            {

            }
        }
        //S_DidConfigs_Temp.OpInfoRef = 1;//需要单独计算
    }
#endif
}


void MainWindow::Slot_Generate(bool checked)
{
    qDebug("Generate Started...");
}

