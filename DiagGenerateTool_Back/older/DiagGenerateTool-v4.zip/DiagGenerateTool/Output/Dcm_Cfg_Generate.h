/*********************************************************************/
/*                       DiagTool.Generate Start                     */
/*********************************************************************/

#ifndef __DCM_CFG_GENERATE_H__
#define __DCM_CFG_GENERATE_H__

#define DcmNumOfDIDSupported		((uint8)2)
#define DcmNumOfRIDSupported		((uint8)6)

//PID Define
#define PID_A1A1		((uint16)0xA1A1)
#define PID_F1B1		((uint16)0xF1B1)


#ifndef DCM_TABLE_SUPPORTED_DID
#define DCM_TABLE_SUPPORTED_DID \
	PID_A1A1, \
	PID_F1B1, \

#endif


#ifndef DCM_TABLE_DID_INFO
#define DCM_TABLE_DID_INFO \
{10,  0,  3}, \
{ 1,  2,  4}, \

#endif


#ifndef DCM_TABLE_DID_OPERATION_INFO
#define DCM_TABLE_DID_OPERATION_INFO \
{0x02, 0x00, 0x01}, \
{0x03, 0x00, 0x01}, \
{0x04, 0x00, 0x09}, \

#endif



#endif
/*********************************************************************/
/*                       DiagTool.Generate Stop                      */
/*********************************************************************/

