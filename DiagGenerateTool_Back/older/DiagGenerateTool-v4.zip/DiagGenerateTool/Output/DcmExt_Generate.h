/*********************************************************************/
/*                       DiagTool.Generate Start                     */
/*********************************************************************/

#ifndef __DCMEXT_GENERATE_H__
#define __DCMEXT_GENERATE_H__

#include "Std_Types.h"
#define DID_0x2FDID_SIZE_2		 ((uint8)2)
//PID Define
#define PID_A1A1		((uint16)0xA1A1)
#define PID_F1B1		((uint16)0xF1B1)

#define SERVICE_22_SUPPORTED
#define SERVICE_2E_SUPPORTED
#define SERVICE_2F_SUPPORTED

#ifndef DCM_TABLE_READ
#define DCM_TABLE_READ \
{PID_A1A1,		fdiag_app_A1A1_Read},\

#endif

#ifndef DCM_TABLE_WRITE
#define DCM_TABLE_WRITE \
{PID_A1A1,		fdiag_app_A1A1_Write},\

#endif

#ifndef DCM_TABLE_IOCTRL
#define DCM_TABLE_IOCTRL \
{\
	PID_F1B1,\
	RETURN_CONTROL_ECU|FREEZE_CURRENT_STATE|RESET_TO_DEFAULT|SHORT_TERM_ADJUST,\
	DID_0x2FDID_SIZE_2,\
	NULL_PTR, \
	fdiag_app_F1B1_IOC, \
	NULL_PTR, \
},\

#endif

#ifdef SERVICE_22_SUPPORTED
uint8 fdiag_app_A1A1_Read(uint8 Buff[]); 
static const PID_RECORD diag_pid_table_rom[] = 
{
	DCM_TABLE_READ
	{0,NULL_PTR}
}; 
#endif

#ifdef SERVICE_2E_SUPPORTED
uint8 fdiag_app_A1A1_Write(uint8 Buff[]); 
static const PID_RECORD diag_write_pid_table_rom[] = 
{
	DCM_TABLE_WRITE
	{0,NULL_PTR}
}; 
#endif

#ifdef SERVICE_2F_SUPPORTED
uint8 fdiag_app_F1B1_IOC(uint8 fl_ctrl_parameter, uint8 *fl_get_ctrl_value); 
static const IOCTL_RECORD ioctl_diag_table_rom[] = 
{
	DCM_TABLE_IOCTRL
	{0, 0, 0, NULL_PTR, NULL_PTR, NULL_PTR}
}; 
#endif


#endif
/*********************************************************************/
/*                       DiagTool.Generate Stop                      */
/*********************************************************************/

