﻿#include "mainwindow.h"
#include "ui_mainwindow.h"

//DID配置
//记录界面中的配置信息
QList<S_DID_Infos_User_Type* > List_DID_Infos_User;
//根据配置信息，再扩展其他需要的配置信息
QList<S_DID_Configs_Type> List_DID_Configs;

//记录所有的DID值，
//用于生成DID_XXXX和DCM_TABLE_SUPPORTED_DID
QList<uint16> List_Did;

//记录DID 操作，数据长度等信息
//用于生成DCM_TABLE_DID_INFO
QList<Dcm_DspDidInfoType> List_DidInfo;

//记录State_Ref及其他,
//用于生成DCM_TABLE_DID_OPERATION_INFO
QList<Dcm_DspDidOpInfoType> List_DidOpInfo;

//用于生成文件，以string形式记录所有的配置
S_File_DidConfigs_Type S_File_DidConfigs;
S_File_RidConfigs_Type S_File_RidConfigs;
S_File_DcmConfigs_Type S_File_DcmConfigs;

QModelIndex Index_CurSelect;
QStringList List_Read_Funtion;
QStringList List_Write_Funtion;
QStringList List_IOC_Funtion;

//RID配置
QList<uint16> List_Rid;
QList<S_RID_Infos_User_Type*> List_RID_Infos_User;
QList<Dcm_DspRidInfoType> List_RidInfo;
QList<Dcm_DspRidSignalInfoType> List_RidSignalInfo;
QList<S_RID_RTN_Record_Type> List_RTN_Record;

/* QTreeView的Item */
QStandardItemModel Stand_Model;
QStandardItem* Item_Diag[2];
QStandardItem* Item_DcmSub[3];
QStandardItem* Item_DemSub[3];

bool l_TableUpdate_Finished = false;

//DID右键菜单
QAction* Ptr_Action_AddDID;
QAction* Ptr_Action_DelDID;
QMenu* Ptr_Menu_Did;

//RID右键菜单
QAction* Ptr_Action_AddRID;
QAction* Ptr_Action_DelRID;
QMenu* Ptr_Menu_Rid;

/* QTabView的Item*/
QTableView* Ptr_TableView_Rid;
QTableView* Ptr_TableView_Dcm;

QStandardItemModel StdModel_Did;
QStandardItemModel StdModel_Rid;
QStandardItemModel StdModel_Dcm;


//配置数据
const State_SID_Ref_Type State_SID_Table[] = \
{\
    {0x22, 2},\
    {0x2E, 3},\
    {0x2F, 4},\
    {0x31, 5}
};

//函数声明
void SaveConfigInfo(void);
void GenerateFiles(void);
void GenerateFiles_ParseConfig(void);
void Generate_Dcm_Cfg_Generate_h(void);
void Generate_DcmExt_Generate_c(void);
void Generate_DcmExt_Generate_h(void);
void GenerateFiles_ParseDidConfig(void);
void GenerateFiles_ParseRidConfig(void);

//函数定义
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    MainWindow_Init();
    connect(ui->But_Generate, &QPushButton::clicked, this, &MainWindow::Slot_Generate);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::MainWindow_Init(void)
{
//    QString Str_Open_Path = QString("./../DiagGenerateTool/Input");
//    QString Str_File_Template = QFileDialog::getOpenFileName(this, "Open Template", \
//                                                             QDir::toNativeSeparators(Str_Open_Path), "*.*");
    QFile File_DiagConfig("./../File_DiagConfig/Input/DiagGenerateTemplate.h");

    //new一个Rid的TableView
    Ptr_TableView_Rid = new QTableView(this);
    Ptr_TableView_Dcm = new QTableView(this);
    Ptr_TableView_Rid->setGeometry(ui->Table_Config->geometry());
    Ptr_TableView_Dcm->setGeometry(ui->Table_Config->geometry());

    //设置QTreeview的属性
    Item_Diag[0] = new QStandardItem("DCM Config");
    Item_Diag[1] = new QStandardItem("DEM Config");

    Item_DcmSub[0] = new QStandardItem("Dcm Config");
    Item_DcmSub[1] = new QStandardItem("DID Table");
    Item_DcmSub[2] = new QStandardItem("RID Table");

    Item_DemSub[0] = new QStandardItem("DTC Table");

    Item_Diag[0]->insertRow(0, Item_DcmSub[0]);
    Item_Diag[0]->insertRow(1, Item_DcmSub[1]);
    Item_Diag[0]->insertRow(2, Item_DcmSub[2]);

    Item_Diag[1]->insertRow(0, Item_DemSub[0]);

    Stand_Model.insertRow(0, Item_Diag[0]);
    Stand_Model.insertRow(1, Item_Diag[1]);

    //禁止编辑
    Item_Diag[0]->setEditable(false);
    Item_Diag[1]->setEditable(false);
    Item_DcmSub[0]->setEditable(false);
    Item_DcmSub[1]->setEditable(false);

    ui->Tree_Config->setModel(&Stand_Model);
    //隐藏header
    ui->Tree_Config->setHeaderHidden(true);

    //设置展开
    ui->Tree_Config->expandAll();

    //设置QTreeView的属性
    connect(ui->Tree_Config, &QTreeView::clicked, this, &MainWindow::Slot_TreeView_Clicled);

    //增加DID Table右键菜单
    Ptr_Menu_Did = new QMenu(ui->Table_Config);
    Ptr_Action_AddDID = Ptr_Menu_Did->addAction("Add Did");
    Ptr_Action_DelDID = Ptr_Menu_Did->addAction("Delete Did");

    ui->Table_Config->addAction(Ptr_Action_AddDID);
    ui->Table_Config->addAction(Ptr_Action_DelDID);

    connect(Ptr_Action_AddDID, &QAction::triggered, this, &MainWindow::Slot_AddDID);
    connect(Ptr_Action_DelDID, &QAction::triggered, this, &MainWindow::Slot_DelDID);

    ui->Table_Config->setContextMenuPolicy(Qt::CustomContextMenu);//必须设置
    connect(ui->Table_Config, &QTableView::customContextMenuRequested, this, &MainWindow::Slot_DidTable_customContextMenuRequested);
    connect(&StdModel_Did, &QStandardItemModel::itemChanged, this, &MainWindow::Slot_UpdateDidInfos);

    //增加RID Table右键菜单
    Ptr_Menu_Rid = new QMenu(ui->Table_Config);
    Ptr_Action_AddRID = Ptr_Menu_Rid->addAction("Add Rid");
    Ptr_Action_DelRID = Ptr_Menu_Rid->addAction("Delete Rid");

    Ptr_TableView_Rid->addAction(Ptr_Action_AddRID);
    Ptr_TableView_Rid->addAction(Ptr_Action_DelRID);

    connect(Ptr_Action_AddRID, &QAction::triggered, this, &MainWindow::Slot_AddRID);
    connect(Ptr_Action_DelRID, &QAction::triggered, this, &MainWindow::Slot_DelRID);

    Ptr_TableView_Rid->setContextMenuPolicy(Qt::CustomContextMenu);//必须设置
    connect(Ptr_TableView_Rid, &QTableView::customContextMenuRequested, this, &MainWindow::Slot_RidTable_customContextMenuRequested);
    connect(&StdModel_Rid, &QStandardItemModel::itemChanged, this, &MainWindow::Slot_UpdateRidInfos);

    //test did
    S_DID_Infos_User_Type* Ptr_Infos_Did_Test = new S_DID_Infos_User_Type[4];
    Ptr_Infos_Did_Test[0].Did = 0xA1A1;
    Ptr_Infos_Did_Test[0].DataLen = 10;
    Ptr_Infos_Did_Test[0].Operation = 0x3;

    Ptr_Infos_Did_Test[1].Did = 0xF1B1;
    Ptr_Infos_Did_Test[1].DataLen = 0x1;
    Ptr_Infos_Did_Test[1].Operation = 0x4;

    List_DID_Infos_User.append(&Ptr_Infos_Did_Test[0]);
    List_DID_Infos_User.append(&Ptr_Infos_Did_Test[1]);
    l_TableUpdate_Finished = true;
    TableView_UpdateDid();
    Slot_UpdateDidInfos(StdModel_Did.item(0,0));

    //test rid
    S_RID_Infos_User_Type* Ptr_Infos_Rid_Test = new S_RID_Infos_User_Type[6];
    Ptr_Infos_Rid_Test[0].Rid = 0x0202;
    Ptr_Infos_Rid_Test[0].Operation = 0xF;
    Ptr_Infos_Rid_Test[0].RoutineControlOptionRecord = 0;
    Ptr_Infos_Rid_Test[0].RoutineType = 0x06;

    Ptr_Infos_Rid_Test[1].Rid = 0x0203;
    Ptr_Infos_Rid_Test[1].Operation = 0xF;
    Ptr_Infos_Rid_Test[1].RoutineControlOptionRecord = 0;
    Ptr_Infos_Rid_Test[1].RoutineType = 0x06;

    Ptr_Infos_Rid_Test[2].Rid = 0xFF01;
    Ptr_Infos_Rid_Test[2].Operation = 0xF;
    Ptr_Infos_Rid_Test[2].RoutineControlOptionRecord = 0;
    Ptr_Infos_Rid_Test[2].RoutineType = 0x06;

    Ptr_Infos_Rid_Test[3].Rid = 0xF103;
    Ptr_Infos_Rid_Test[3].Operation = 0xF;
    Ptr_Infos_Rid_Test[3].RoutineControlOptionRecord = 0;
    Ptr_Infos_Rid_Test[3].RoutineType = 0x06;

    Ptr_Infos_Rid_Test[4].Rid = 0xF104;
    Ptr_Infos_Rid_Test[4].Operation = 0xF;
    Ptr_Infos_Rid_Test[4].RoutineControlOptionRecord = 0;
    Ptr_Infos_Rid_Test[4].RoutineType = 0x06;

    Ptr_Infos_Rid_Test[5].Rid = 0xF11E;
    Ptr_Infos_Rid_Test[5].Operation = 0xF;
    Ptr_Infos_Rid_Test[5].RoutineControlOptionRecord = 1;
    Ptr_Infos_Rid_Test[5].RoutineType = 0x06;

    List_RID_Infos_User.append(&Ptr_Infos_Rid_Test[0]);
    List_RID_Infos_User.append(&Ptr_Infos_Rid_Test[1]);
    List_RID_Infos_User.append(&Ptr_Infos_Rid_Test[2]);
    List_RID_Infos_User.append(&Ptr_Infos_Rid_Test[3]);
    List_RID_Infos_User.append(&Ptr_Infos_Rid_Test[4]);
    List_RID_Infos_User.append(&Ptr_Infos_Rid_Test[5]);

    TableView_UpdateRid();
    Slot_UpdateRidInfos(StdModel_Rid.item(0,0));
    //end test
}

void MainWindow::Slot_TreeView_Clicled(QModelIndex index)
{
    QString Str_ItemName = ui->Tree_Config->model()->itemData(index).values().at(0).toString();
    if(Str_ItemName == "DID Table")
    {
        Ptr_TableView_Rid->hide();
        ui->Table_Config->show();
        TableView_UpdateDid();
    }
    else if(Str_ItemName == "RID Table")
    {
        ui->Table_Config->hide();
        Ptr_TableView_Rid->show();
        TableView_UpdateRid();
    }
    else
    {
        /* ToBeDefine */
    }
}

//依据配置信息更新TableView
void MainWindow::TableView_UpdateDid(void)
{
    qDebug() << "Update TableView";
    uint8 row = 0;
    uint8 col = 0;
    QList<QStandardItem*> List_Row_Item;    //每一行的数据
    QStringList Strlist_Header;
    QStringList Strlist_HeaderTip;
    QStandardItem* Ptr_Item;
    //QStandardItem* Model_Header[4];
    //QList<QStandardItem*> List_StdItem_Temp;

    Print_Info_User();
    //设置表行数和列数
    StdModel_Did.clear();
    StdModel_Did.setColumnCount(5);
    row = List_DID_Infos_User.count();
    col = 5;

    //设置表头和ToolTip
    Strlist_Header << "DID" << "READ" << "WRITE" << "DataLen(Byte)" << "IOCTRL";
    Strlist_HeaderTip << "DID" << QString::fromLocal8Bit("配置是否支持Read功能") \
                      << QString::fromLocal8Bit("配置是否支持Write功能") \
                      << QString::fromLocal8Bit("如果配置READ或WRITE 则数据长度应该指定")\
                      << QString::fromLocal8Bit("配置是否支持IOCTRL");

    for(int i = 0; i < Strlist_Header.size(); i++)
    {
        Ptr_Item = new QStandardItem(Strlist_Header.at(i));
        Ptr_Item->setTextAlignment(Qt::AlignCenter);
        Ptr_Item->setToolTip(Strlist_HeaderTip.at(i));
        StdModel_Did.setHorizontalHeaderItem(i,Ptr_Item);
    }


    //设置DID表的信息
    for(int i = 0; i < row; i++)
    {
        List_Row_Item.clear();
        for(int j = 0; j < col; j++)
        {
            Ptr_Item = new QStandardItem();
            //设置文字居中对齐
            Ptr_Item->setTextAlignment(Qt::AlignCenter);
            switch(j)
            {
                case (0):
                    Ptr_Item->setText(QString::number(List_DID_Infos_User.at(i)->Did, 16).toUpper());
                    break;
                case (1):
                    if((List_DID_Infos_User.at(i)->Operation & DID_READ) != 0)
                    {
                        Ptr_Item->setCheckState(Qt::Checked);
                    }
                    else
                    {
                        Ptr_Item->setCheckState(Qt::Unchecked);
                    }
                    /* 禁止编辑, 使能Check */
                    Ptr_Item->setEditable(false);
                    Ptr_Item->setCheckable(true);
                    break;
                case (2):
                    if((List_DID_Infos_User.at(i)->Operation & DID_WRITE) != 0)
                    {
                        Ptr_Item->setCheckState(Qt::Checked);
                    }
                    else
                    {
                        Ptr_Item->setCheckState(Qt::Unchecked);
                    }
                    /* 禁止编辑, 使能Check */
                    Ptr_Item->setEditable(false);
                    Ptr_Item->setCheckable(true);
                    break;
                case (3):
                    Ptr_Item->setText(QString::number(List_DID_Infos_User.at(i)->DataLen, 10));
                    break;
                case (4):
                    if((List_DID_Infos_User.at(i)->Operation & DID_IOCTRL) != 0)
                    {
                        Ptr_Item->setCheckState(Qt::Checked);
                    }
                    else
                    {
                        Ptr_Item->setCheckState(Qt::Unchecked);
                    }
                    /* 禁止编辑, 使能Check */
                    Ptr_Item->setEditable(false);
                    Ptr_Item->setCheckable(true);
                    break;
                default:
                        break;
            }
            List_Row_Item.append(Ptr_Item);
        }
        StdModel_Did.insertRow(i, List_Row_Item);
    }
    ui->Table_Config->setModel(&StdModel_Did);
}


//如果TableView为空时，右键任何位置都可以弹出菜单
//如果TableView不为空时，则只有在TabView有效index下才能弹出菜单,
void MainWindow::Slot_DidTable_customContextMenuRequested(const QPoint &pos)
{
    bool Enable_Menu = false;
    QModelIndex index = ui->Table_Config->indexAt(pos);
    qDebug() << "index at : " << index;
    sint8 row = index.row();
    if(row == (-1))
    {
        if(List_Did.isEmpty())
        {
            Enable_Menu = true;
        }
        else
        {
            Enable_Menu = false;
        }
    }
    else
    {
        Enable_Menu = true;
        Index_CurSelect = index;
    }

    if(Enable_Menu == true)
    {
        //弹出Did右键菜单
        Ptr_Menu_Did->exec(QCursor::pos());
        //Ptr_Menu_Rid->exec(QCursor::pos());
    }
}

void MainWindow::Slot_RidTable_customContextMenuRequested(const QPoint &pos)
{
    bool Enable_Menu = false;
    QModelIndex index = Ptr_TableView_Rid->indexAt(pos);
    qDebug() << "index at : " << index;
    sint8 row = index.row();
    if(row == (-1))
    {
        if(List_Rid.isEmpty())
        {
            Enable_Menu = true;
        }
        else
        {
            Enable_Menu = false;
        }
    }
    else
    {
        Enable_Menu = true;
        Index_CurSelect = index;
    }

    if(Enable_Menu == true)
    {
        //弹出Did右键菜单
        Ptr_Menu_Rid->exec(QCursor::pos());
    }
}

void MainWindow::Slot_AddDID(bool checked)
{
    qDebug("Add Did");
    //New 1个新的配置，加入到List中
    S_DID_Infos_User_Type* Ptr_Infos_Add = new S_DID_Infos_User_Type;
    Ptr_Infos_Add->Did = 0;
    Ptr_Infos_Add->DataLen = 0;
    Ptr_Infos_Add->Operation = DID_NONE;
    List_DID_Infos_User.append(Ptr_Infos_Add);

    l_TableUpdate_Finished = false;
    TableView_UpdateDid();
    l_TableUpdate_Finished = true;
}

void MainWindow::Slot_DelDID(bool checked)
{
    qDebug("Del Did");
    QModelIndex CurIndex = Index_CurSelect;
    List_DID_Infos_User.removeAt(CurIndex.row());
    TableView_UpdateDid();
}


void MainWindow::Slot_AddRID(bool checked)
{
    qDebug("Add Rid");
    //New 1个新的配置，加入到List中
    S_RID_Infos_User_Type* Ptr_Infos_Add = new S_RID_Infos_User_Type;
    Ptr_Infos_Add->Rid = 0;
    Ptr_Infos_Add->Operation = 0xF;
    Ptr_Infos_Add->RoutineType = 0x06;
    Ptr_Infos_Add->RoutineControlOptionRecord = 0;
    List_RID_Infos_User.append(Ptr_Infos_Add);

    l_TableUpdate_Finished = false;
    TableView_UpdateRid();
    l_TableUpdate_Finished = true;
}

void MainWindow::Slot_DelRID(bool checked)
{
    qDebug("Del Rid");
    QModelIndex CurIndex = Index_CurSelect;
    List_RID_Infos_User.removeAt(CurIndex.row());
    TableView_UpdateRid();
}

void MainWindow::TableView_UpdateRid(void)
{
    QStringList Strlist_Header;
    QStringList Strlist_HeaderTip;
    QStandardItem* Ptr_Item;
    QList<QStandardItem*> List_Row_Item;    //每一行的数据
    uint8 row = 0;
    uint8 col = 0;

    //设置表行数和列数
    StdModel_Rid.clear();
    StdModel_Rid.setColumnCount(4);
    row = List_RID_Infos_User.count();
    col = 4;

    //设置表头和ToolTip
    Strlist_Header << "RID" << "Operation" << "RCORL" << "RoutineType";
    Strlist_HeaderTip << "RID" << QString::fromLocal8Bit("配置Rid支持的操作") \
                      << QString::fromLocal8Bit("配置RoutineControlOptionRecord Length") \
                      << QString::fromLocal8Bit("配置Routine 类型");

    for(int i = 0; i < Strlist_Header.size(); i++)
    {
        Ptr_Item = new QStandardItem(Strlist_Header.at(i));
        Ptr_Item->setTextAlignment(Qt::AlignCenter);
        Ptr_Item->setToolTip(Strlist_HeaderTip.at(i));
        StdModel_Rid.setHorizontalHeaderItem(i,Ptr_Item);
    }

    //设置RID表的信息
    for(int i = 0; i < row; i++)
    {
        List_Row_Item.clear();
        for(int j = 0; j < col; j++)
        {
            Ptr_Item = new QStandardItem();
            //设置文字居中对齐
            Ptr_Item->setTextAlignment(Qt::AlignCenter);
            switch(j)
            {
                case (0):
                    Ptr_Item->setText(QString::number(List_RID_Infos_User.at(i)->Rid, 16).toUpper());
                    break;
                case (1):
                    Ptr_Item->setText("START | STOP | RESULT");
                    //设置不可编辑
                    Ptr_Item->setEditable(false);
                    break;
                case (2):
                    Ptr_Item->setText(QString::number(List_RID_Infos_User.at(i)->RoutineControlOptionRecord, 10));
                    break;
                case (3):
                    Ptr_Item->setText("ROUTINE_TYPE_2 | RC_STOP_SERVICE");
                    //设置不可编辑
                    Ptr_Item->setEditable(false);
                    break;
                default:
                    break;

            }
            List_Row_Item.append(Ptr_Item);
        }
        StdModel_Rid.insertRow(i, List_Row_Item);
    }

    Ptr_TableView_Rid->setModel(&StdModel_Rid);
    //第2和3列加宽
    Ptr_TableView_Rid->setColumnWidth(1, 200);
    Ptr_TableView_Rid->setColumnWidth(3, 300);
}


//根据用户配置信息，生成Did的配置表
void MainWindow::Slot_UpdateDidInfos(QStandardItem *item)
{
    qDebug("Did Data Changed...");

    uint8 i = 0;
    uint8 j = 0;
    bool Result = 0;
    uint8 row = 0;
    uint8 col = 0;
    uint8 OpInfo_Counter = 0;
    S_DID_Infos_User_Type* Ptr_S_DidInfos_Temp_User;
    uint8 Did_Operation = 0;
    S_DID_Configs_Type* Ptr_S_DidConfigs_Temp;
    Dcm_DspDidInfoType S_DidInfo_Temp;
    Dcm_DspDidOpInfoType S_DidOpInfo_Temp;

    if(l_TableUpdate_Finished != true)
    {
        return;
    }

    row = StdModel_Did.rowCount();
    col = StdModel_Did.columnCount();

    Ptr_S_DidConfigs_Temp = new S_DID_Configs_Type;

    //清除当前的DID配置信息
    List_Did.clear();
    List_DidInfo.clear();
    List_DidOpInfo.clear();

    Print_TableView();
    //获取界面上用户配置的信息
    if(row != 0)
    {
        //删除原来的配置信息
        List_DID_Infos_User.clear();
        //重新获取界面的配置信息，
        for(i = 0; i < row; i++)
        {
            Ptr_S_DidInfos_Temp_User = new S_DID_Infos_User_Type;

            Did_Operation = DID_NONE;
            Ptr_S_DidInfos_Temp_User->Did = StdModel_Did.item(i,0)->text().toUInt(&Result, 16);
            Ptr_S_DidInfos_Temp_User->DataLen = StdModel_Did.item(i,3)->text().toUInt(&Result, 10);

            /* Read Flag */
            if(StdModel_Did.item(i, 1)->checkState())
            {
                Did_Operation |= DID_READ;
            }
            /* Write Flag */
            if(StdModel_Did.item(i, 2)->checkState())
            {
                Did_Operation |= DID_WRITE;
            }
            /* IoCtrl Flag */
            if(StdModel_Did.item(i, 4)->checkState())
            {
                Did_Operation |= DID_IOCTRL;
            }

            Ptr_S_DidInfos_Temp_User->Operation = Did_Operation;
            List_DID_Infos_User.append(Ptr_S_DidInfos_Temp_User);
        }
    }

    //生成Did的配置表
    Print_Info_User();
    for(int i = 0; i < List_DID_Infos_User.count(); i++)
    {
        Ptr_S_DidConfigs_Temp->Did = List_DID_Infos_User.at(i)->Did;
        Ptr_S_DidConfigs_Temp->Length = List_DID_Infos_User.at(i)->DataLen;
        Ptr_S_DidConfigs_Temp->Operation = List_DID_Infos_User.at(i)->Operation;

        S_DidInfo_Temp.Length = Ptr_S_DidConfigs_Temp->Length;
        S_DidInfo_Temp.Operations = Ptr_S_DidConfigs_Temp->Operation;

        uint8 count = sizeof(State_SID_Table) / sizeof(State_SID_Table[0]);
        if(0 != (Ptr_S_DidConfigs_Temp->Operation & DID_READ))
        {
            for(int j = 0; j < count; j++)
            {
                if(State_SID_Table[j].Sid == (0x22))
                {
                    S_DidOpInfo_Temp.State_Ref = State_SID_Table[j].StateRef;
                    break;
                }
            }
            S_DidOpInfo_Temp.CallTypes = 1;//默认值
            S_DidOpInfo_Temp.SignalInfo_Ref = 0;//默认值

            S_DidInfo_Temp.OpInfoRef = OpInfo_Counter;
            List_DidOpInfo.append(S_DidOpInfo_Temp);
            OpInfo_Counter++;
        }

        if(0 != (Ptr_S_DidConfigs_Temp->Operation & DID_WRITE))
        {
            for(int j = 0; j < count; j++)
            {
                if(State_SID_Table[j].Sid == (0x2E))
                {
                    S_DidOpInfo_Temp.State_Ref = State_SID_Table[j].StateRef;
                    break;
                }
            }

            S_DidOpInfo_Temp.CallTypes = 1;//默认值
            S_DidOpInfo_Temp.SignalInfo_Ref = 0;//默认值

            List_DidOpInfo.append(S_DidOpInfo_Temp);
            OpInfo_Counter++;
        }


        if(0 != (Ptr_S_DidConfigs_Temp->Operation & DID_IOCTRL))
        {
            for(int j = 0; j < count; j++)
            {
                if(State_SID_Table[j].Sid == (0x2F))
                {
                    S_DidOpInfo_Temp.State_Ref = State_SID_Table[j].StateRef;
                    break;
                }
            }

            S_DidOpInfo_Temp.CallTypes = 9;
            S_DidOpInfo_Temp.SignalInfo_Ref = 0;//默认值

            S_DidInfo_Temp.OpInfoRef = OpInfo_Counter;
            List_DidOpInfo.append(S_DidOpInfo_Temp);
            OpInfo_Counter++;
        }

        List_Did.append(Ptr_S_DidConfigs_Temp->Did);
        List_DidInfo.append(S_DidInfo_Temp);
    }
    Print_Did_Infos();
}

//根据用户配置信息，生成Rid的配置表
void MainWindow::Slot_UpdateRidInfos(QStandardItem *item)
{
    qDebug("Rid Data Changed...");

    uint8 i = 0;
    uint8 j = 0;
    bool Result = 0;
    uint8 row = 0;
    uint8 col = 0;
    uint8 State_Ref_Temp;
    S_RID_Infos_User_Type* Ptr_S_RidInfos_Temp_User;
    Dcm_DspRidInfoType S_RidInfo_Temp;
    Dcm_DspRidSignalInfoType S_RidSignalInfo_Temp;
    S_RID_RTN_Record_Type S_Rid_RTN_Record_Temp;

    if(l_TableUpdate_Finished != true)
    {
        return;
    }

    row = StdModel_Rid.rowCount();
    col = StdModel_Rid.columnCount();

    //清除当前的DID配置信息
    List_Rid.clear();
    List_RidInfo.clear();
    List_RidSignalInfo.clear();
    List_RTN_Record.clear();

    //获取界面上用户配置的信息
    if(row != 0)
    {
        //删除原来的配置信息
        List_RID_Infos_User.clear();
        //重新获取界面的配置信息，
        for(i = 0; i < row; i++)
        {
            Ptr_S_RidInfos_Temp_User = new S_RID_Infos_User_Type;

            Ptr_S_RidInfos_Temp_User->Rid = StdModel_Rid.item(i,0)->text().toUInt(&Result, 16);
            Ptr_S_RidInfos_Temp_User->Operation = 0xF;
            Ptr_S_RidInfos_Temp_User->RoutineType = 0x06;
            Ptr_S_RidInfos_Temp_User->RoutineControlOptionRecord = StdModel_Rid.item(i,2)->text().toUInt(&Result, 10);
            List_RID_Infos_User.append(Ptr_S_RidInfos_Temp_User);
        }
    }

    //生成Rid的配置表
//    Print_Info_User();
    //获取0x31服务对应的State_Ref
    for(uint8 j = 0; j < sizeof(State_SID_Table) / sizeof(State_SID_Table[0]); j++)
    {
        if(State_SID_Table[j].Sid == (0x31))
        {
            State_Ref_Temp = State_SID_Table[j].StateRef;
            break;
        }
    }

    for(int i = 0; i < List_RID_Infos_User.count(); i++)
    {
        List_Rid.append(List_RID_Infos_User.at(i)->Rid);

        S_RidInfo_Temp.SignalInfo_Ref = i;
        S_RidInfo_Temp.State_Ref = State_Ref_Temp;
        S_RidInfo_Temp.Operation = 0xF;//默认值，暂不可配置
        List_RidInfo.append(S_RidInfo_Temp);

        S_RidSignalInfo_Temp.RidOpFunc_Ref = 0;//默认为0，实际代码中也只有1个Rid的分发函数
        S_RidSignalInfo_Temp.Req_Length = List_RID_Infos_User.at(i)->RoutineControlOptionRecord;
        S_RidSignalInfo_Temp.Resp_Length = 0xF;
        S_RidSignalInfo_Temp.OpType = 0xF;
        List_RidSignalInfo.append(S_RidSignalInfo_Temp);

        S_Rid_RTN_Record_Temp.routine_time = 0;//DR_TIME_NOT_REQ
        S_Rid_RTN_Record_Temp.routine_id = List_RID_Infos_User.at(i)->Rid;
        S_Rid_RTN_Record_Temp.routine_type = 0x06;//ROUTINE_TYPE_2|RC_STOP_SERVICE
        S_Rid_RTN_Record_Temp.sup_session = 0x04;
        S_Rid_RTN_Record_Temp.sess_sec_stat = 0x04;
        S_Rid_RTN_Record_Temp.supp_seclvl = 0;
        S_Rid_RTN_Record_Temp.DID_LHVSD_Check_Status = 0;//LHVSD_CHECK_NOT_NEEDED
        S_Rid_RTN_Record_Temp.Str_StartFunction = QString("ApplDiagStart_%1_RotineControl")\
                                                  .arg(List_RID_Infos_User.at(i)->Rid,4,16, QChar('0'));
        S_Rid_RTN_Record_Temp.Str_ResultFunction = QString("ApplDiagResults_%1_RotineControl")\
                                                  .arg(List_RID_Infos_User.at(i)->Rid,4,16, QChar('0'));
        S_Rid_RTN_Record_Temp.Str_StatusFunction = QString("ApplDiagStatus_%1_RotineControl")\
                                                  .arg(List_RID_Infos_User.at(i)->Rid,4,16, QChar('0'));
        S_Rid_RTN_Record_Temp.Str_StopFunction = QString("ApplDiagTerminal_%1_RotineControl")\
                                                  .arg(List_RID_Infos_User.at(i)->Rid,4,16, QChar('0'));
        List_RTN_Record.append(S_Rid_RTN_Record_Temp);
    }
}


void MainWindow::Slot_Generate(bool checked)
{
    qDebug("------Start: Generate ConfigFile Started");
    GenerateFiles();
    qDebug("------End: Generate ConfigFile Started");
}


void MainWindow::Print_Info_User(void)
{
    qDebug("------Start: Print User Config");
    for(uint8 i = 0; i < List_DID_Infos_User.count(); i++)
    {
        qDebug() << QString::number(List_DID_Infos_User.at(i)->Did, 16) \
                 << List_DID_Infos_User.at(i)->DataLen \
                 << List_DID_Infos_User.at(i)->Operation;
    }
    qDebug("------End: Print User Config");
}

//打印用户配置的表格信息
void MainWindow::Print_TableView(void)
{
    uint8 i = 0;
    uint8 j = 0;
    bool Result = 0;
    uint8 row = StdModel_Did.rowCount();
    uint8 col = StdModel_Did.columnCount();

    qDebug() << "------Start: Print TableView: " << row << col;
    for(i = 0; i < row; i++)
    {
        qDebug() << StdModel_Did.item(i,0)->text().toUInt(&Result, 16) \
                 << StdModel_Did.item(i,1)->checkState() \
                 << StdModel_Did.item(i,2)->checkState() \
                 << StdModel_Did.item(i,3)->text().toUInt(&Result, 10) \
                 << StdModel_Did.item(i,4)->checkState();
    }
    qDebug() << "------End: Print TableView";
}

//打印需生成的配置信息
void MainWindow::Print_Did_Infos(void)
{
    uint8 i = 0;
    uint8 j = 0;
    qDebug() << "------Start: Print Did Infos: ";

    qDebug() << "Did Table:";
    for(i = 0 ; i < List_Did.count(); i++)
    {
        qDebug() << QString::number(List_Did.at(i), 16);
    }

    qDebug() << "DidInfo Table:";
    qDebug() << "Length" << "OpInfoRef" << "Operations";
    for(i = 0; i < List_DidInfo.count(); i++)
    {
        qDebug() << List_DidInfo.at(i).Length \
                 << List_DidInfo.at(i).OpInfoRef \
                 << List_DidInfo.at(i).Operations;
    }

    qDebug() << "DidOpInfo Table:";
    qDebug() << "State_Ref" << "SignalInfo_Ref" << "CallTypes";
    for(i = 0; i < List_DidOpInfo.count(); i++)
    {
        qDebug() << List_DidOpInfo.at(i).State_Ref \
                 << List_DidOpInfo.at(i).SignalInfo_Ref \
                 << List_DidOpInfo.at(i).CallTypes;
    }

    qDebug() << "------End: Print Did Infos: ";
}

//保存配置信息
void SaveConfigInfo(void)
{

}
//创建文件
void GenerateFiles(void)
{
    GenerateFiles_ParseConfig();
    Generate_Dcm_Cfg_Generate_h();
    Generate_DcmExt_Generate_c();
    Generate_DcmExt_Generate_h();
}

void GenerateFiles_ParseConfig(void)
{
    GenerateFiles_ParseDidConfig();
    GenerateFiles_ParseRidConfig();
}

void GenerateFiles_ParseDidConfig()
{
    uint8 i = 0;
    QString Str_Temp;
    QString Str_Temp_Functions;
    List_Read_Funtion.clear();
    List_Write_Funtion.clear();
    List_IOC_Funtion.clear();
    S_File_DidConfigs.Str_ReadFunctions_Declaration.clear();
    S_File_DidConfigs.Str_WriteFunctions_Declaration.clear();
    S_File_DidConfigs.Str_IOCFunctions_Declaration.clear();

    //PID Define
    Str_Temp = QString("//PID Define\n");
    for(i = 0; i < List_Did.count(); i++)
    {
        QString Str_Did = QString::number(List_Did.at(i), 16).toUpper();
        Str_Temp.append(QString("#define PID_%1").arg(Str_Did)) \
                .append(QString("\t\t((uint16)0x%1)\n").arg(Str_Did));
    }
    S_File_DidConfigs.Str_DidMacros = Str_Temp;
    S_File_DidConfigs.Str_DidCount = QString("#define DcmNumOfDIDSupported\t\t((uint8)%1)").arg(List_Did.count());

    //DCM_TABLE_SUPPORTED_DID
    Str_Temp = QString("#ifndef DCM_TABLE_SUPPORTED_DID\n").append("#define DCM_TABLE_SUPPORTED_DID \\");
    for(i = 0; i < List_Did.count(); i++)
    {
        QString Str_Did = QString::number(List_Did.at(i), 16).toUpper();
        Str_Temp.append(QString("\n\tPID_%1, \\").arg(Str_Did));
    }
    Str_Temp.append("\n\n#endif\n");
    S_File_DidConfigs.Str_DidTable = Str_Temp;

    //DCM_TABLE_DID_INFO
    Str_Temp.clear();
    Str_Temp = QString("#ifndef DCM_TABLE_DID_INFO\n").append("#define DCM_TABLE_DID_INFO \\\n");
    for(i = 0; i < List_DidInfo.count(); i++)
    {
        Str_Temp.append("{");
        Str_Temp.append(QString("%1, %2, %3}, \\\n") \
                .arg(List_DidInfo.at(i).Length, 2) \
                .arg(List_DidInfo.at(i).OpInfoRef, 2) \
                .arg(List_DidInfo.at(i).Operations, 2));
    }
    Str_Temp.append("\n#endif\n");
    S_File_DidConfigs.Str_DidInfoTable = Str_Temp;


    //DCM_TABLE_DID_OPERATION_INFO
    Str_Temp = QString("#ifndef DCM_TABLE_DID_OPERATION_INFO\n").append("#define DCM_TABLE_DID_OPERATION_INFO \\\n");
    for(i = 0; i < List_DidOpInfo.count(); i++)
    {
        Str_Temp.append("{");
        Str_Temp.append(QString("0x%1, 0x%2, 0x%3}, \\\n") \
                .arg(List_DidOpInfo.at(i).State_Ref, 2, 16, QChar('0')) \
                .arg(List_DidOpInfo.at(i).SignalInfo_Ref, 2, 16, QChar('0')) \
                .arg(List_DidOpInfo.at(i).CallTypes, 2, 16, QChar('0')));
    }
    Str_Temp.append("\n#endif\n");
    S_File_DidConfigs.Str_DidOpInfoTable = Str_Temp;


    //DCM_TABLE_READ
    //Str_Temp.append("#ifdef SERVICE_22_SUPPORTED\n");
    Str_Temp = QString("#ifndef DCM_TABLE_READ\n").append("#define DCM_TABLE_READ \\\n");
    for(i = 0; i < List_Did.count(); i++)
    {
        QString Str_Did = QString::number(List_Did.at(i), 16).toUpper();
        QString Str_Did_Function;
        if(0 != (List_DidInfo.at(i).Operations & DID_READ))
        {
            Str_Did_Function.append(QString("fdiag_app_%1_Read").arg(Str_Did));
            List_Read_Funtion.append(Str_Did_Function);
            if(!S_File_DcmConfigs.Str_ServiceDefine.contains("#define SERVICE_22_SUPPORTED\n"))
            {
                S_File_DcmConfigs.Str_ServiceDefine.append("#define SERVICE_22_SUPPORTED\n");
            }
        }
        else
        {
            continue;
        }
        Str_Temp.append("{");
        Str_Temp.append(QString("PID_%1,\t\t").arg(Str_Did)).append(Str_Did_Function);
        Str_Temp.append("},\\\n");
    }
    Str_Temp.append("\n#endif\n");
    S_File_DidConfigs.Str_DcmTable_Read = Str_Temp;

    //DCM_TABLE_WRITE
    //Str_Temp.append("#ifdef SERVICE_2E_SUPPORTED\n");
    Str_Temp = QString("#ifndef DCM_TABLE_WRITE\n").append("#define DCM_TABLE_WRITE \\\n");
    for(i = 0; i < List_Did.count(); i++)
    {
        QString Str_Did = QString::number(List_Did.at(i), 16).toUpper();
        QString Str_Did_Function;
        if(0 != (List_DidInfo.at(i).Operations & DID_WRITE))
        {
            Str_Did_Function.append(QString("fdiag_app_%1_Write").arg(Str_Did));
            List_Write_Funtion.append(Str_Did_Function);
            if(!S_File_DcmConfigs.Str_ServiceDefine.contains("#define SERVICE_2E_SUPPORTED\n"))
            {
                S_File_DcmConfigs.Str_ServiceDefine.append("#define SERVICE_2E_SUPPORTED\n");
            }
        }
        else
        {
            continue;
        }
        Str_Temp.append("{");
        Str_Temp.append(QString("PID_%1,\t\t").arg(Str_Did)).append(Str_Did_Function);
        Str_Temp.append("},\\\n");
    }
    Str_Temp.append("\n#endif\n");
    S_File_DidConfigs.Str_DcmTable_Write = Str_Temp;

    //DCM_TABLE_IOCTRL
    //Str_Temp.append("#ifdef SERVICE_2F_SUPPORTED\n");
    Str_Temp = QString("#ifndef DCM_TABLE_IOCTRL\n").append("#define DCM_TABLE_IOCTRL \\\n");
    for(i = 0; i < List_Did.count(); i++)
    {
        QString Str_Did = QString::number(List_Did.at(i), 16).toUpper();
        QString Str_Did_Function;
        if(0 != (List_DidInfo.at(i).Operations & DID_IOCTRL))
        {
            Str_Did_Function.append(QString("fdiag_app_%1_IOC").arg(Str_Did));
            List_IOC_Funtion.append(Str_Did_Function);
            if(!S_File_DcmConfigs.Str_ServiceDefine.contains("#define SERVICE_2F_SUPPORTED\n"))
            {
                S_File_DcmConfigs.Str_ServiceDefine.append("#define SERVICE_2F_SUPPORTED\n");
            }
        }
        else
        {
            continue;
        }
        Str_Temp.append("{\\\n");
        Str_Temp.append(QString("\tPID_%1,\\\n").arg(Str_Did)) \
                .append("\tRETURN_CONTROL_ECU|FREEZE_CURRENT_STATE|RESET_TO_DEFAULT|SHORT_TERM_ADJUST,\\\n") \
                .append("\tDID_0x2FDID_SIZE_2,\\\n") \
                .append("\tNULL_PTR, \\\n") \
                .append(Str_Did_Function.insert(0, "\t").append(", \\\n")) \
                .append("\tNULL_PTR, \\\n");
        Str_Temp.append("},\\\n");
    }
    Str_Temp.append("\n#endif\n");
    S_File_DidConfigs.Str_DcmTable_IOCTRL = Str_Temp;


    //Read Functions
    Str_Temp.clear();
    Str_Temp_Functions.clear();
    Str_Temp.append("#ifdef SERVICE_22_SUPPORTED\n");
    Str_Temp_Functions.append("#ifdef SERVICE_22_SUPPORTED\n");
    for(i = 0; i < List_Read_Funtion.count(); i++)
    {
        //函数声明
        Str_Temp.append("/****************************************************************************\n") \
                .append(QString("Function Name     : %1\n").arg(List_Read_Funtion.at(i))) \
                .append("Description       : This function is used to read \n") \
                .append("Invocation        : diagnosis_app \n") \
                .append("Parameters        : None \n") \
                .append("Return Value      : UINT8 \n") \
                .append("Critical Section  : None \n") \
                .append("******************************************************************************/\n");
        Str_Temp.append(QString("uint8 %1(uint8 Buff[]) \n").arg(List_Read_Funtion.at(i))) \
                .append("{ \n") \
                .append("\treturn (0);\n") \
                .append("} \n\n");

        Str_Temp_Functions.append(QString("uint8 %1(uint8 Buff[]); \n")\
                                  .arg(List_Read_Funtion.at(i)));
    }
    Str_Temp.append("#endif\n");
    Str_Temp_Functions.append("static const PID_RECORD diag_pid_table_rom[] = \n") \
            .append("{\n\tDCM_TABLE_READ\n\t{0,NULL_PTR}\n}; \n")\
            .append("#endif\n");

    S_File_DidConfigs.Str_ReadFunctions_Define = Str_Temp;
    S_File_DidConfigs.Str_ReadFunctions_Declaration = Str_Temp_Functions;

    //Write Functions
    Str_Temp.clear();
    Str_Temp_Functions.clear();
    Str_Temp.append("#ifdef SERVICE_2E_SUPPORTED\n");
    Str_Temp_Functions.append("#ifdef SERVICE_2E_SUPPORTED\n");
    for(i = 0; i < List_Write_Funtion.count(); i++)
    {
        //函数声明
        Str_Temp.append("/****************************************************************************\n") \
                .append(QString("Function Name     : %1\n").arg(List_Write_Funtion.at(i))) \
                .append("Description       : This function is used to write \n") \
                .append("Invocation        : diagnosis_app \n") \
                .append("Parameters        : None \n") \
                .append("Return Value      : UINT8 \n") \
                .append("Critical Section  : None \n") \
                .append("******************************************************************************/\n");
        Str_Temp.append(QString("uint8 %1(uint8 Buff[]) \n").arg(List_Write_Funtion.at(i))) \
                .append("{ \n") \
                .append("\treturn (0);\n") \
                .append("} \n\n");

        Str_Temp_Functions.append(QString("uint8 %1(uint8 Buff[]); \n")\
                                 .arg(List_Write_Funtion.at(i)));
    }
    Str_Temp.append("#endif\n");

    Str_Temp_Functions.append("static const PID_RECORD diag_write_pid_table_rom[] = \n") \
            .append("{\n\tDCM_TABLE_WRITE\n\t{0,NULL_PTR}\n}; \n")\
            .append("#endif\n");
    S_File_DidConfigs.Str_WriteFunctions_Declaration = Str_Temp_Functions;
    S_File_DidConfigs.Str_WriteFunctions_Define = Str_Temp;

    //IOC Functions
    Str_Temp.clear();
    Str_Temp_Functions.clear();
    Str_Temp.append("#ifdef SERVICE_2F_SUPPORTED\n");
    Str_Temp_Functions.append("#ifdef SERVICE_2F_SUPPORTED\n");
    S_File_DidConfigs.Str_IOCFunctions_Declaration.append("#ifdef SERVICE_2F_SUPPORTED\n");
    for(i = 0; i < List_IOC_Funtion.count(); i++)
    {
        //函数声明
        Str_Temp.append("/****************************************************************************\n") \
                .append(QString("Function Name     : %1\n").arg(List_IOC_Funtion.at(i))) \
                .append("Description       : This function is used to control IO \n") \
                .append("Invocation        : diagnosis_app \n") \
                .append("Parameters        : None \n") \
                .append("Return Value      : UINT8 \n") \
                .append("Critical Section  : None \n") \
                .append("******************************************************************************/\n");
        Str_Temp.append(QString("uint8 %1(uint8 fl_ctrl_parameter, uint8 *fl_get_ctrl_value) \n").arg(List_IOC_Funtion.at(i))) \
                .append("{ \n") \
                .append("\treturn (0);\n") \
                .append("} \n\n");

        Str_Temp_Functions.append(QString("uint8 %1(uint8 fl_ctrl_parameter, uint8 *fl_get_ctrl_value); \n")\
                                  .arg(List_IOC_Funtion.at(i)));
    }
    Str_Temp_Functions.append("static const IOCTL_RECORD ioctl_diag_table_rom[] = \n") \
            .append("{\n\tDCM_TABLE_IOCTRL\n\t{0, 0, 0, NULL_PTR, NULL_PTR, NULL_PTR}\n}; \n")\
            .append("#endif\n");
    Str_Temp.append("#endif\n");
    S_File_DidConfigs.Str_IOCFunctions_Define = Str_Temp;
    S_File_DidConfigs.Str_IOCFunctions_Declaration = Str_Temp_Functions;
}


void GenerateFiles_ParseRidConfig(void)
{
    uint8 i = 0;
    QString Str_Temp;
    QString Str_Temp_Functions;

    S_File_RidConfigs.Str_RidFunctions_Define.clear();
    S_File_RidConfigs.Str_RidFunctions_Declaration.clear();

    //Service Define
    if(0 != List_Rid.count())
    {
        if(!S_File_DcmConfigs.Str_ServiceDefine.contains("#define SERVICE_31_SUPPORTED\n"))
        {
            S_File_DcmConfigs.Str_ServiceDefine.append("#define SERVICE_31_SUPPORTED\n");
        }
    }
    //RID Define
    Str_Temp = QString("//RID Define\n");
    for(i = 0; i < List_Rid.count(); i++)
    {
        QString Str_Rid = QString::number(List_Rid.at(i), 16).toUpper();
        Str_Temp.append(QString("#define RID_%1").arg(Str_Rid,4,QChar('0'))) \
                .append(QString("\t\t((uint16)0x%1)\n").arg(Str_Rid,4,QChar('0')));
    }
    S_File_RidConfigs.Str_RidMacros = Str_Temp;
    S_File_RidConfigs.Str_RidCount = QString("#define DcmNumOfRIDSupported\t\t((uint8)%1)").arg(List_Rid.count());

    //DCM_TABLE_SUPPORTED_RID
    Str_Temp = QString("#ifndef DCM_TABLE_SUPPORTED_RID\n").append("#define DCM_TABLE_SUPPORTED_RID \\");
    for(i = 0; i < List_Rid.count(); i++)
    {
        QString Str_Rid = QString::number(List_Rid.at(i), 16).toUpper();
        Str_Temp.append(QString("\n\tRID_%1, \\").arg(Str_Rid, 4, QChar('0')));
    }
    Str_Temp.append("\n\n#endif\n");
    S_File_RidConfigs.Str_RidTable = Str_Temp;

    //DCM_TABLE_RID_INFO
    Str_Temp.clear();
    Str_Temp = QString("#ifndef DCM_TABLE_RID_INFO\n").append("#define DCM_TABLE_RID_INFO \\\n");
    for(i = 0; i < List_RidInfo.count(); i++)
    {
        Str_Temp.append(QString("{0x%1, 0x%2, 0x%3}, \\\n") \
                .arg(QString::number(List_RidInfo.at(i).SignalInfo_Ref,16), 1, QChar('0')) \
                .arg(QString::number(List_RidInfo.at(i).State_Ref, 16), 1, QChar('0')) \
                .arg(QString::number(List_RidInfo.at(i).Operation,16).toUpper(), 2, QChar('0')));
    }
    Str_Temp.append("\n#endif\n");
    S_File_RidConfigs.Str_RidInfoTable = Str_Temp;

    //DCM_TABLE_RID_SIGNAL_INFO
    Str_Temp.clear();
    Str_Temp = QString("#ifndef DCM_TABLE_RID_SIGNAL_INFO\n").append("#define DCM_TABLE_RID_SIGNAL_INFO \\\n");
    for(i = 0; i < List_RidSignalInfo.count(); i++)
    {
        QString Str_RidOpFunc_Ref = QString::number(List_RidSignalInfo.at(i).RidOpFunc_Ref, 16).toUpper();
        QString Str_Req_Length = QString::number(List_RidSignalInfo.at(i).Req_Length, 16).toUpper();
        QString Str_Resp_Length = QString::number(List_RidSignalInfo.at(i).Resp_Length, 16).toUpper();
        QString Str_OpType = QString::number(List_RidSignalInfo.at(i).OpType, 16).toUpper();
        Str_Temp.append(QString("{0x%1, 0x%2, 0x%3, 0x%4}, \\\n") \
                        .arg(Str_RidOpFunc_Ref, 1, QChar('0')) \
                        .arg(Str_Req_Length, 1, QChar('0')) \
                        .arg(Str_Resp_Length, 2, QChar('0')) \
                        .arg(Str_OpType, 2, QChar('0')));
    }
    Str_Temp.append("\n#endif\n");
    S_File_RidConfigs.Str_RidSignalInfoTable = Str_Temp;

    //DCM_TABLE_ROUTINE_CONTROL
    Str_Temp.clear();
    Str_Temp = QString("#ifndef DCM_TABLE_ROUTINE_CONTROL\n").append("#define DCM_TABLE_ROUTINE_CONTROL\t\t\\\n");
    for(i = 0; i < List_RTN_Record.count(); i++)
    {
        QString Str_Rid = QString::number(List_Rid.at(i), 16).toUpper();
        Str_Temp.append(QString("{\\\n\t%1,\\\n \t%2,\\\n \t%3,\\\n \t%4,\\\n \t%5,\\\n \t%6,\\\n \t%7,\\\n \t%8,\\\n \t%9,\\\n \t%10,\\\n \t%11\\\n}, \\\n") \
                        .arg("DR_TIME_NOT_REQ") \
                        .arg(QString("RID_%1").arg(Str_Rid, 4, QChar('0'))) \
                        .arg(QString("ROUTINE_TYPE_2 | RC_STOP_SERVICE")) \
                        .arg(List_RTN_Record.at(i).sup_session)\
                        .arg(List_RTN_Record.at(i).sess_sec_stat)\
                        .arg(List_RTN_Record.at(i).supp_seclvl)\
                        .arg(QString("LHVSD_CHECK_NOT_NEEDED"))\
                        .arg(List_RTN_Record.at(i).Str_StartFunction)\
                        .arg(List_RTN_Record.at(i).Str_ResultFunction)\
                        .arg(List_RTN_Record.at(i).Str_StatusFunction)\
                        .arg(List_RTN_Record.at(i).Str_StopFunction));
    }
    Str_Temp.append("\n#endif\n");
    S_File_RidConfigs.Str_Rid_RTN_Record = Str_Temp;

    //Rid Functions Define and Declaration
    Str_Temp.clear();
    Str_Temp_Functions.clear();
    Str_Temp.append("#ifdef SERVICE_31_SUPPORTED\n");
    Str_Temp_Functions.append("#ifdef SERVICE_31_SUPPORTED\n");
    for(i = 0; i < List_RTN_Record.count(); i++)
    {
        QString Str_Start_FunctionName = List_RTN_Record.at(i).Str_StartFunction;
        QString Str_Result_FunctionName = List_RTN_Record.at(i).Str_ResultFunction;
        QString Str_Status_FunctionName = List_RTN_Record.at(i).Str_StatusFunction;
        QString Str_Stop_FunctionName = List_RTN_Record.at(i).Str_StopFunction;

        //Start 函数声明
        Str_Temp.append("/****************************************************************************\n") \
                .append(QString("Function Name     : %1\n").arg(Str_Start_FunctionName)) \
                .append("Description       : This function is used to Start Routine \n") \
                .append("Invocation        : diagnosis_app \n") \
                .append("Parameters        : None \n") \
                .append("Return Value      : uint8, uint16* \n") \
                .append("Critical Section  : None \n") \
                .append("******************************************************************************/\n");
        Str_Temp.append(QString("uint8 %1(uint8 p_diag_buf_U8A[],uint16 *p_resdatalen_ptr) \n")\
                        .arg(Str_Start_FunctionName)) \
                .append("{ \n") \
                .append("\treturn (0);\n") \
                .append("} \n\n");
        //Start 函数定义
        Str_Temp_Functions.append(QString("uint8 %1(uint8 p_diag_buf_U8A[],uint16 *p_resdatalen_ptr); \n")\
                                  .arg(Str_Start_FunctionName));

        //Result 函数声明
        Str_Temp.append("/****************************************************************************\n") \
                .append(QString("Function Name     : %1\n").arg(Str_Result_FunctionName)) \
                .append("Description       : This function is used to get routine result  \n") \
                .append("Invocation        : diagnosis_app \n") \
                .append("Parameters        : None \n") \
                .append("Return Value      : uint8, uint16* \n") \
                .append("Critical Section  : None \n") \
                .append("******************************************************************************/\n");
        Str_Temp.append(QString("uint8 %1(uint8 p_diag_buf_U8A[],uint16 *p_resdatalen_ptr) \n")\
                        .arg(Str_Result_FunctionName)) \
                .append("{ \n") \
                .append("\treturn (0);\n") \
                .append("} \n\n");
        //Result 函数定义
        Str_Temp_Functions.append(QString("uint8 %1(uint8 p_diag_buf_U8A[],uint16 *p_resdatalen_ptr); \n")\
                                  .arg(Str_Result_FunctionName));

        //Status 函数声明
        Str_Temp.append("/****************************************************************************\n") \
                .append(QString("Function Name     : %1\n").arg(Str_Status_FunctionName)) \
                .append("Description       : This function is used to get routine status \n") \
                .append("Invocation        : diagnosis_app \n") \
                .append("Parameters        : None \n") \
                .append("Return Value      : boolean \n") \
                .append("Critical Section  : None \n") \
                .append("******************************************************************************/\n");
        Str_Temp.append(QString("boolean %1(void) \n").arg(Str_Status_FunctionName)) \
                .append("{ \n") \
                .append("\treturn (TRUE);\n") \
                .append("} \n\n");
        //Status 函数定义
        Str_Temp_Functions.append(QString("boolean %1(void); \n").arg(Str_Status_FunctionName));

        //Stop 函数声明
        Str_Temp.append("/****************************************************************************\n") \
                .append(QString("Function Name     : %1\n").arg(Str_Stop_FunctionName)) \
                .append("Description       : This function is used to Stop Routine \n") \
                .append("Invocation        : diagnosis_app \n") \
                .append("Parameters        : None \n") \
                .append("Return Value      : void \n") \
                .append("Critical Section  : None \n") \
                .append("******************************************************************************/\n");
        Str_Temp.append(QString("void %1(void)\n").arg(Str_Stop_FunctionName)) \
                .append("{ \n") \
                .append("\treturn ;\n") \
                .append("} \n\n");
        Str_Temp.append("\n");

        //Stop 函数定义
        Str_Temp_Functions.append(QString("void %1(void); \n").arg(Str_Stop_FunctionName));
        Str_Temp_Functions.append("\n");
    }

    Str_Temp.append("#endif\n");
    Str_Temp_Functions.append("static RTN_CTRL_RECORD diag_routine_ctrl_table_rom[] = \n") \
            .append("{\n\tDCM_TABLE_ROUTINE_CONTROL\n\t{0, 0, 0, 0, 0, 0, 0, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR}\n}; \n")\
            .append("#endif\n");

    S_File_RidConfigs.Str_RidFunctions_Define = Str_Temp;
    S_File_RidConfigs.Str_RidFunctions_Declaration = Str_Temp_Functions;
}

void Generate_Dcm_Cfg_Generate_h(void)
{
    QString Str_ConfigFile_Name = "./../DiagGenerateTool/Output/Dcm_Cfg_Generate.h";
    QFile File_Config(Str_ConfigFile_Name);
    QTextStream Text_Out(&File_Config);

    //移除之前的生成文件
    if(File_Config.exists())
    {
      File_Config.remove();
    }

    if(false != File_Config.open(QIODevice::ReadWrite | QIODevice::Text))
    {
        //写入文件头
        Text_Out << "/*********************************************************************/" << endl\
                 << "/*                       DiagTool.Generate Start                     */" << endl\
                 << "/*********************************************************************/" << endl\
                 << endl \
                 << "#ifndef __DCM_CFG_GENERATE_H__" << endl\
                 << "#define __DCM_CFG_GENERATE_H__" << endl \
                 << endl;

        Text_Out << S_File_DidConfigs.Str_DidCount << endl;
        Text_Out << S_File_DidConfigs.Str_DidMacros << endl << endl;
        Text_Out << S_File_DidConfigs.Str_DidTable << endl << endl;
        Text_Out << S_File_DidConfigs.Str_DidInfoTable << endl << endl;
        Text_Out << S_File_DidConfigs.Str_DidOpInfoTable << endl << endl;

        Text_Out << S_File_RidConfigs.Str_RidCount << endl << endl;
        Text_Out << S_File_RidConfigs.Str_RidMacros << endl << endl;
        Text_Out << S_File_RidConfigs.Str_RidTable << endl << endl;
        Text_Out << S_File_RidConfigs.Str_RidInfoTable << endl << endl;
        Text_Out << S_File_RidConfigs.Str_RidSignalInfoTable << endl << endl;

        //写入文件尾
        Text_Out << endl \
                 << "#endif" << endl \
                 << "/*********************************************************************/" << endl\
                 << "/*                       DiagTool.Generate Stop                      */" << endl\
                 << "/*********************************************************************/" << endl\
                 << endl;
        File_Config.close();
    }
    else
    {
        qDebug("File Open Failed");
    }
}
void Generate_DcmExt_Generate_c(void)
{
    QString Str_ConfigFile_Name = "./../DiagGenerateTool/Output/DcmExt_Generate.c";
    QFile File_Config(Str_ConfigFile_Name);
    QTextStream Text_Out(&File_Config);

    //移除之前的生成文件
    if(File_Config.exists())
    {
      File_Config.remove();
    }

    if(false != File_Config.open(QIODevice::ReadWrite | QIODevice::Text))
    {
        //写入文件头
        Text_Out << "/*********************************************************************/" << endl\
                 << "/*                       DiagTool.Generate Start                     */" << endl\
                 << "/*********************************************************************/" << endl\
                 << endl \
                 << "#ifndef __DCMEXT_GENERATE_C__" << endl\
                 << "#define __DCMEXT_GENERATE_C__" << endl \
                 << endl;

        Text_Out << "#include \"DcmExt.h\"" << endl;
        Text_Out << "#include \"DcmExt_Generate.h\"" << endl;

        Text_Out << S_File_DidConfigs.Str_ReadFunctions_Define << endl;
        Text_Out << S_File_DidConfigs.Str_WriteFunctions_Define << endl;
        Text_Out << S_File_DidConfigs.Str_IOCFunctions_Define << endl;

        Text_Out << S_File_RidConfigs.Str_RidFunctions_Define << endl;

        //写入文件尾
        Text_Out << endl \
                 << "#endif" << endl \
                 << "/*********************************************************************/" << endl\
                 << "/*                       DiagTool.Generate Stop                      */" << endl\
                 << "/*********************************************************************/" << endl\
                 << endl;
        File_Config.close();
    }
    else
    {
        qDebug("File Open Failed");
    }
}
void Generate_DcmExt_Generate_h(void)
{
    QString Str_ConfigFile_Name = "./../DiagGenerateTool/Output/DcmExt_Generate.h";
    QFile File_Config(Str_ConfigFile_Name);
    QTextStream Text_Out(&File_Config);

    //移除之前的生成文件
    if(File_Config.exists())
    {
      File_Config.remove();
    }

    if(false != File_Config.open(QIODevice::ReadWrite | QIODevice::Text))
    {
        //写入文件头
        Text_Out << "/*********************************************************************/" << endl\
                 << "/*                       DiagTool.Generate Start                     */" << endl\
                 << "/*********************************************************************/" << endl\
                 << endl \
                 << "#ifndef __DCMEXT_GENERATE_H__" << endl\
                 << "#define __DCMEXT_GENERATE_H__" << endl \
                 << endl;

        Text_Out << "#include \"Std_Types.h\"" << endl << endl;

        Text_Out << "#define DID_0x2FDID_SIZE_2\t\t ((uint8)2)\n";
        Text_Out << "#define DR_TIME_NOT_REQ\t\t ((uint32)0)\n";
        Text_Out << "#define ROUTINE_TYPE_1\t\t(0x01u)\n";
        Text_Out << "#define ROUTINE_TYPE_2\t\t(0x02u)\n";
        Text_Out << "#define RC_STOP_SERVICE\t\t(0x04u)\n";
        Text_Out << "#define RC_SELFTEST\t\t(0x10u)\n";
        Text_Out << "#define NO_SPACE_AVAILABLE\t\t(0xFF)\n";
        Text_Out << "#define LHVSD_CHECK_NEEDED\t\t(0xFF)\n";
        Text_Out << "#define LHVSD_CHECK_NOT_NEEDED\t\t(0x00)\n\n";

        Text_Out << S_File_DcmConfigs.Str_ServiceDefine << endl;
        Text_Out << S_File_DidConfigs.Str_DidMacros << endl;
        Text_Out << S_File_DidConfigs.Str_DcmTable_Read << endl;
        Text_Out << S_File_DidConfigs.Str_DcmTable_Write << endl;
        Text_Out << S_File_DidConfigs.Str_DcmTable_IOCTRL << endl;
        Text_Out << S_File_DidConfigs.Str_ReadFunctions_Declaration << endl;
        Text_Out << S_File_DidConfigs.Str_WriteFunctions_Declaration << endl;
        Text_Out << S_File_DidConfigs.Str_IOCFunctions_Declaration << endl;

        Text_Out << S_File_RidConfigs.Str_RidMacros << endl;
        Text_Out << S_File_RidConfigs.Str_Rid_RTN_Record << endl;
        Text_Out << S_File_RidConfigs.Str_RidFunctions_Declaration << endl;


        //写入文件尾
        Text_Out << endl \
                 << "#endif" << endl \
                 << "/*********************************************************************/" << endl\
                 << "/*                       DiagTool.Generate Stop                      */" << endl\
                 << "/*********************************************************************/" << endl\
                 << endl;
        File_Config.close();
    }
    else
    {
        qDebug("File Open Failed");
    }
}
