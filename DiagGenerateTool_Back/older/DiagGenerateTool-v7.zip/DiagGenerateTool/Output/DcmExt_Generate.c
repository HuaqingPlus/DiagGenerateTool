/*********************************************************************/
/*                       DiagTool.Generate Start                     */
/*********************************************************************/

#ifndef __DCMEXT_GENERATE_C__
#define __DCMEXT_GENERATE_C__

#include "DcmExt.h"
#include "DcmExt_Generate.h"

#define E_OK		(0u)

#ifdef SERVICE_22_SUPPORTED
/****************************************************************************
Function Name     : fdiag_app_A1_Read
Description       : This function is used to read 
Invocation        : diagnosis_app 
Parameters        : None 
Return Value      : UINT8 
Critical Section  : None 
******************************************************************************/
uint8 fdiag_app_A1_Read(uint8 Buff[]) 
{ 
	return (E_OK);
} 

#endif

#ifdef SERVICE_2E_SUPPORTED
/****************************************************************************
Function Name     : fdiag_app_B1_Write
Description       : This function is used to write 
Invocation        : diagnosis_app 
Parameters        : None 
Return Value      : UINT8 
Critical Section  : None 
******************************************************************************/
uint8 fdiag_app_B1_Write(uint8 Buff[]) 
{ 
	return (0);
} 

#endif

#ifdef SERVICE_2F_SUPPORTED
/****************************************************************************
Function Name     : fdiag_app_C1_IOC
Description       : This function is used to control IO 
Invocation        : diagnosis_app 
Parameters        : None 
Return Value      : UINT8 
Critical Section  : None 
******************************************************************************/
uint8 fdiag_app_C1_IOC(uint8 fl_ctrl_parameter, uint8 *fl_get_ctrl_value) 
{ 
	return (0);
} 

#endif

#ifdef SERVICE_31_SUPPORTED
#endif


#endif
/*********************************************************************/
/*                       DiagTool.Generate Stop                      */
/*********************************************************************/

