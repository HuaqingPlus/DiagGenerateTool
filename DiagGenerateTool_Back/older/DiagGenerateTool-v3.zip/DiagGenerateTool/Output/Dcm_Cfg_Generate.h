#ifndef __DIAGGENERATETEPMLATE_H__
#define __DIAGGENERATETEPMLATE_H__

/*********************************************************************/
/*                       DiagTool.Generate Start                     */
/*********************************************************************/

//DID Define
#define DID_AAAA		((uint16)0xAAAA)
#define DID_BBBB		((uint16)0xBBBB)
#define DID_CCCC		((uint16)0xCCCC)

#ifndef DCM_TABLE_SUPPORTED_DID
#define DCM_TABLE_SUPPORTED_DID \
	DID_AAAA, \
	DID_BBBB, \
	DID_CCCC, \

#endif

#ifndef DCM_TABLE_DID_INFO
#define DCM_TABLE_DID_INFO \
{0, 0, 3}},\
{0, 2, 3}},\
{0, 4, 4}},\

#endif

#ifndef DCM_TABLE_DID_OPERATION_INFO
#define DCM_TABLE_DID_OPERATION_INFO \
{0x2, 0x0, 0x1}},\
{0x3, 0x0, 0x1}},\
{0x2, 0x0, 0x1}},\
{0x3, 0x0, 0x1}},\
{0x4, 0x0, 0x9}},\

#endif

#ifndef PROD_SPEC_DIAG_PID_TABLE
#define PROD_SPEC_DIAG_PID_TABLE \
{DID_AAAA,		fdiag_app_AAAA_Read},\
{DID_BBBB,		fdiag_app_BBBB_Read},\

#endif

#ifndef PROD_SPEC_DIAG_WRITE_PID_TABLE
#define PROD_SPEC_DIAG_WRITE_PID_TABLE \
{DID_AAAA,		fdiag_app_AAAA_WRITE},\
{DID_BBBB,		fdiag_app_BBBB_WRITE},\

#endif

#ifndef PROD_SPEC_DIAG_IOCTL_BY_ID_FOR_EOL_TABLE
#define PROD_SPEC_DIAG_IOCTL_BY_ID_FOR_EOL_TABLE \
{
	DID_CCCC,\
	RETURN_CONTROL_ECU|FREEZE_CURRENT_STATE|RESET_TO_DEFAULT|SHORT_TERM_ADJUST,\
	DID_0x2FDID_SIZE_2,\
	NULL, \
	fdiag_app_CCCC_IOC, \
	NULL, \
},\

#endif

/****************************************************************************
Function Name     : fdiag_app_AAAA_Read
Description       : This function is used to read 
Invocation        : diagnosis_app 
Parameters        : None 
Return Value      : UINT8 
Critical Section  : None 
******************************************************************************/
static uint8 fdiag_app_AAAA_Read(uint8 Buff[]) 
{ 
	return (0)
} 

/****************************************************************************
Function Name     : fdiag_app_BBBB_Read
Description       : This function is used to read 
Invocation        : diagnosis_app 
Parameters        : None 
Return Value      : UINT8 
Critical Section  : None 
******************************************************************************/
static uint8 fdiag_app_BBBB_Read(uint8 Buff[]) 
{ 
	return (0)
} 


/****************************************************************************
Function Name     : fdiag_app_AAAA_WRITE
Description       : This function is used to write 
Invocation        : diagnosis_app 
Parameters        : None 
Return Value      : UINT8 
Critical Section  : None 
******************************************************************************/
static uint8 fdiag_app_AAAA_WRITE(uint8 Buff[]) 
{ 
	return (0)
} 

/****************************************************************************
Function Name     : fdiag_app_BBBB_WRITE
Description       : This function is used to write 
Invocation        : diagnosis_app 
Parameters        : None 
Return Value      : UINT8 
Critical Section  : None 
******************************************************************************/
static uint8 fdiag_app_BBBB_WRITE(uint8 Buff[]) 
{ 
	return (0)
} 


/****************************************************************************
Function Name     : fdiag_app_CCCC_IOC
Description       : This function is used to write 
Invocation        : diagnosis_app 
Parameters        : None 
Return Value      : UINT8 
Critical Section  : None 
******************************************************************************/
static uint8 fdiag_app_CCCC_IOC((uint8 fl_ctrl_parameter, uint8 *fl_get_ctrl_value) 
{ 
	return (0)
} 



/*********************************************************************/
/*                       DiagTool.Generate Stop                      */
/*********************************************************************/

#endif
