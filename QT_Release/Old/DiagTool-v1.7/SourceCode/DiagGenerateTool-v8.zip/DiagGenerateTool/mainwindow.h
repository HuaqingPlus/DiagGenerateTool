﻿#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QtDebug>
#include <QFileDialog>
#include <QDir>
#include <QAbstractItemModel>
#include <QStandardItemModel>
#include <QStandardItem>
#include <QTextCodec>
#include <QFile>
#include <QDomDocument>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

//数据类型定义
typedef uint8_t uint8;
typedef int8_t sint8;
typedef uint16_t uint16;
typedef uint32_t uint32;

typedef struct
{
    uint16 Did;
    uint8 Operation;
    uint8 DataLen;
}S_DID_Infos_User_Type;

//RID
typedef struct
{
    uint16 Rid;
    uint8 Operation;
    uint8 RoutineControlOptionRecord;
    uint8 RoutineType;
}S_RID_Infos_User_Type;

typedef struct
{
    QString Item;
    QString Value;
}S_DcmGeneral_Items_Type;




//class 定义
class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    void MainWindow_Init(void);

public:
    void TableView_UpdateDid(void);
    void TableView_UpdateRid(void);
    void TableView_UpdateDcmGeneral(void);
    void Print_Info_User(void);
    void Print_TableView(void);
    void Print_Did_Infos(void);

public slots:
    void Slot_OpenConfig(bool checked);
    void Slot_TreeView_Clicled(QModelIndex index);
    void Slot_DidTable_customContextMenuRequested(const QPoint &pos);
    void Slot_RidTable_customContextMenuRequested(const QPoint &pos);
    void Slot_AddDID(bool checked);
    void Slot_DelDID(bool checked);
    void Slot_AddRID(bool checked);
    void Slot_DelRID(bool checked);
    void Slot_Generate(bool checked);
    void Slot_UpdateDidInfos(QStandardItem *item);
    void Slot_UpdateRidInfos(QStandardItem *item);
    void Slot_UpdateDcmGeneralInfos(QStandardItem *item);
    void Slot_FileMenu_Triggered(QAction* Action);

private:
    Ui::MainWindow *ui;
};
#endif // MAINWINDOW_H


