﻿#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "ProjectManager.h"

extern MainWindow* MW;
//当前配置工程
QString Str_CurProject_Name;

//新建一个工程
void PM_NewProject(void)
{
    Str_CurProject_Name.clear();
    List_DID_Infos_User.clear();
    List_RID_Infos_User.clear();
    List_DcmGeneral_Infos_User.clear();

    //设置Dcm_General的默认配置项
    QStringList StrList_Items;
    QStringList StrList_Value;
    StrList_Items << "DcmTesterResponseAddr" \
                  << "DcmTesterSourcePhyAddr" \
                  << "DcmTesterSourceFuncAddr" \
                  << "DcmDslBufferSize";
    StrList_Value << "2" << "1" << "0" << "4095";

    for(uint8 i = 0; i < StrList_Items.count(); i++)
    {
        S_DcmGeneral_Items_Type* Ptr_DcmGeneral_Test = new S_DcmGeneral_Items_Type;
        Ptr_DcmGeneral_Test->Item = StrList_Items.at(i);
        Ptr_DcmGeneral_Test->Value = StrList_Value.at(i);

        List_DcmGeneral_Infos_User.append(Ptr_DcmGeneral_Test);
    }
}

//保存配置工程
void PM_SaveConfigInfo(void)
{
    uint8 i = 0;
    QFile File_DiagConfig;
    //QFile File_DiagConfig("./../DiagGenerateTool/Config/Diag_Config.xml");Str_FileName
    if(!Str_CurProject_Name.isEmpty())
    {
        File_DiagConfig.setFileName(Str_CurProject_Name);
    }
    else
    {
        Str_CurProject_Name = QFileDialog::getSaveFileName(nullptr,"Save Config File",\
                                                           "./../DiagGenerateTool/Config",\
                                                          ("xml (*.xml)"));
        //QFile File_DiagConfig(Str_CurProject_Name);
    }
    QTextStream Text_Config(&File_DiagConfig);
    QDomText Text;
    QDomDocument Dom_DiagConfig;
    QDomElement SubNode;
    QDomProcessingInstruction Instruction;

    QDomElement Root = Dom_DiagConfig.createElement("DiagConfigs");
    QDomElement Child_l1_DcmConfig = Dom_DiagConfig.createElement("DcmConfig");
    QDomElement Child_l1_DemConfig = Dom_DiagConfig.createElement("DemConfig");

    QDomElement Child_l2_DcmGeneralConfig = Dom_DiagConfig.createElement("DcmGeneralConfig");
    QDomElement Child_l2_DidConfig = Dom_DiagConfig.createElement("DidConfig");
    QDomElement Child_l2_RidConfig = Dom_DiagConfig.createElement("RidConfig");

    //添加1级节点
    Root.appendChild(Child_l1_DcmConfig);
    Root.appendChild(Child_l1_DemConfig);

    //添加2级节点
    Child_l1_DcmConfig.appendChild(Child_l2_DcmGeneralConfig);
    Child_l1_DcmConfig.appendChild(Child_l2_DidConfig);
    Child_l1_DcmConfig.appendChild(Child_l2_RidConfig);

    //DcmGeneralConfig子节点
    for(i = 0; i < List_DcmGeneral_Infos_User.count(); i++)
    {
        SubNode = Dom_DiagConfig.createElement("subItem");
        SubNode.setTagName("DcmGeneralConfig:");
        SubNode.setAttribute(List_DcmGeneral_Infos_User.at(i)->Item, List_DcmGeneral_Infos_User.at(i)->Value);
        Child_l2_DcmGeneralConfig.appendChild(SubNode);
    }

    //DidConfig子节点
    for(i = 0; i < List_DID_Infos_User.count(); i++)
    {
       SubNode = Dom_DiagConfig.createElement("subItem");
       SubNode.setTagName("DidConfig:");
       SubNode.setAttribute("Did", QString::number(List_DID_Infos_User.at(i)->Did, 16));
       SubNode.setAttribute("DataLen", QString::number(List_DID_Infos_User.at(i)->DataLen, 16));
       SubNode.setAttribute("Operation", QString::number(List_DID_Infos_User.at(i)->Operation, 16));
       Child_l2_DidConfig.appendChild(SubNode);
    }

    //RidConfig子节点
    for(i = 0; i < List_RID_Infos_User.count(); i++)
    {
       SubNode = Dom_DiagConfig.createElement("subItem");
       SubNode.setTagName("RidConfig:");
       SubNode.setAttribute("Rid", QString::number(List_RID_Infos_User.at(i)->Rid, 16));
       SubNode.setAttribute("Operation", QString::number(List_RID_Infos_User.at(i)->Operation, 16));
       SubNode.setAttribute("RoutineType", QString::number(List_RID_Infos_User.at(i)->RoutineType, 16));
       SubNode.setAttribute("RoutineControlOptionRecord", QString::number(List_RID_Infos_User.at(i)->RoutineControlOptionRecord, 16));
       Child_l2_RidConfig.appendChild(SubNode);
    }

    //打开文件
    if(!File_DiagConfig.open(QFile::WriteOnly | QFile::Text))
    {
        qDebug() << "Open Config Failed";
        return;
    }
    else
    {
        qDebug() << "Open Config Success";
    }

    //加入说明
    //Instruction = Dom_DiagConfig.createProcessingInstruction("xml", "version = \"1.0\", encoding = \"UTF-8\"");
    //Dom_DiagConfig.appendChild(Instruction);
    Dom_DiagConfig.appendChild(Root);

    //保存文件，缩进量设置为4
    Dom_DiagConfig.save(Text_Config, 4);
    //关闭文件
    File_DiagConfig.close();
}



//读取配置
void PM_OpenProject(void)
{

    uint8 i = 0;
    uint8 j = 0;
    bool Result = false;
    QString Str_FileName = QFileDialog::getOpenFileName(nullptr,"Open Config File",\
                                                        "./../DiagGenerateTool/Config",\
                                                        ("xml (*.xml)"));
    Str_CurProject_Name = Str_FileName;

    //QFile File_DiagConfig("./../DiagGenerateTool/Config/Diag_Config.xml");
    qDebug() << "ConfigFile Path" << Str_FileName;

    QFile File_DiagConfig(Str_FileName);
    QTextStream Text_Config(&File_DiagConfig);
    QDomText Text;
    QDomNodeList List_Node;
    QDomNamedNodeMap DomAttr_Map;
    QString Str_Key;
    QString Str_Value;
    S_DcmGeneral_Items_Type* DcmGeneral_Temp;
    S_DID_Infos_User_Type* Did_UserType_Temp;
    S_RID_Infos_User_Type* Rid_UserType_Temp;
    QDomDocument Dom_DiagConfig;

    //1. xml -> List_xxxx_Infos_User
    if(!File_DiagConfig.open(QFile::ReadOnly))
    {
        qDebug() << "Open Config Failed";
        return;
    }
    else
    {
        qDebug() << "Open Config Success";
        //将文件的内容读到DomDocument中
        QString Str;
        int ErrorLine;
        int ErrorColumn;
        if (!Dom_DiagConfig.setContent(&File_DiagConfig, false, &Str, &ErrorLine, &ErrorColumn))
        {
            qDebug() << "add setcontent error..." << "errorStr&&&&" \
                     << Str << "errorLine" << ErrorLine << "errorColume" << ErrorLine;
        }
        else
        {
            qDebug() << "Setcontent Succcess" ;
        }
        File_DiagConfig.close();
    }

    List_DcmGeneral_Infos_User.clear();
    //通过TagName获取所有NodeList
    List_Node = Dom_DiagConfig.elementsByTagName("DcmGeneralConfig:");
    //解析List_Node
    for(i = 0; i < List_Node.count(); i++)
    {
        DcmGeneral_Temp = new S_DcmGeneral_Items_Type;
        DomAttr_Map = List_Node.at(i).attributes();
        for(j =0; j < DomAttr_Map.count(); j++)
        {
            Str_Key = DomAttr_Map.item(j).toAttr().name();
            Str_Value = DomAttr_Map.item(j).toAttr().value();
            DcmGeneral_Temp->Item = Str_Key;
            DcmGeneral_Temp->Value = Str_Value;
            List_DcmGeneral_Infos_User.append(DcmGeneral_Temp);
        }
    }

    List_DID_Infos_User.clear();
    List_Node = Dom_DiagConfig.elementsByTagName("DidConfig:");
    for(i = 0; i < List_Node.count(); i++)
    {
        Did_UserType_Temp = new S_DID_Infos_User_Type;
        DomAttr_Map = List_Node.at(i).attributes();
        for(j =0; j < DomAttr_Map.count(); j++)
        {
            Str_Key = DomAttr_Map.item(j).toAttr().name();
            Str_Value = DomAttr_Map.item(j).toAttr().value();
            if("Did" == Str_Key)
            {
                Did_UserType_Temp->Did = Str_Value.toUInt(&Result, 16);
            }
            else if("Operation" == Str_Key)
            {
                Did_UserType_Temp->Operation = Str_Value.toUInt(&Result, 16);
            }
            else if("DataLen" == Str_Key)
            {
                Did_UserType_Temp->DataLen = Str_Value.toUInt(&Result, 16);
            }
            else
            {
                /* do nothing */
            }
        }
        List_DID_Infos_User.append(Did_UserType_Temp);
    }

    List_RID_Infos_User.clear();
    List_Node = Dom_DiagConfig.elementsByTagName("RidConfig:");
    for(i = 0; i < List_Node.count(); i++)
    {
        Rid_UserType_Temp = new S_RID_Infos_User_Type;
        DomAttr_Map = List_Node.at(i).attributes();
        for(j =0; j < DomAttr_Map.count(); j++)
        {
            Str_Key = DomAttr_Map.item(j).toAttr().name();
            Str_Value = DomAttr_Map.item(j).toAttr().value();
            if("Rid" == Str_Key)
            {
                Rid_UserType_Temp->Rid = Str_Value.toUInt(&Result, 16);
            }
            else if("RoutineType" == Str_Key)
            {
                Rid_UserType_Temp->RoutineType = Str_Value.toUInt(&Result, 16);
            }
            else if("Operation" == Str_Key)
            {
                Rid_UserType_Temp->Operation = Str_Value.toUInt(&Result, 16);
            }
            else if("RoutineControlOptionRecord" == Str_Key)
            {
                Rid_UserType_Temp->RoutineControlOptionRecord = Str_Value.toUInt(&Result, 16);
            }
            else
            {
                /* do nothing */
            }
        }
        List_RID_Infos_User.append(Rid_UserType_Temp);
    }

    //2. List_xxxx_Infos_User -> StdModel_xxxx (用于界面显示)
    MW->TableView_UpdateDcmGeneral();
    MW->TableView_UpdateDid();
    MW->TableView_UpdateRid();
}
