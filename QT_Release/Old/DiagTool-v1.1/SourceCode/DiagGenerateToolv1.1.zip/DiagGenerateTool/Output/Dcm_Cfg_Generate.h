/*********************************************************************/
/*                       DiagTool.Generate Start                     */
/*********************************************************************/

#ifndef __DCM_CFG_GENERATE_H__
#define __DCM_CFG_GENERATE_H__

//DcmGeneralConfig
#define DcmTesterResponseAddr		(2u)
#define DcmTesterSourcePhyAddr		(1u)
#define DcmTesterSourceFuncAddr		(0u)
#define DcmDslBufferSize		(4095u)


#define DcmNumOfDIDSupported		((uint8)0)
#define DcmDspNumOfDidOpInfo		((uint16)0)

//PID Define


#ifndef DCM_TABLE_SUPPORTED_DID
#define DCM_TABLE_SUPPORTED_DID \

#endif


#ifndef DCM_TABLE_DID_INFO
#define DCM_TABLE_DID_INFO \

#endif


#ifndef DCM_TABLE_DID_OPERATION_INFO
#define DCM_TABLE_DID_OPERATION_INFO \

#endif


#define DcmNumOfRIDSupported		((uint8)0)
#define DcmDspNumOfRidSignalInfo		((uint16)0)

//RID Define


#ifndef DCM_TABLE_SUPPORTED_RID
#define DCM_TABLE_SUPPORTED_RID \

#endif


#ifndef DCM_TABLE_RID_INFO
#define DCM_TABLE_RID_INFO \

#endif


#ifndef DCM_TABLE_RID_SIGNAL_INFO
#define DCM_TABLE_RID_SIGNAL_INFO \

#endif



#endif
/*********************************************************************/
/*                       DiagTool.Generate Stop                      */
/*********************************************************************/

