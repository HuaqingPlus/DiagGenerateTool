/*********************************************************************/
/*                       DiagTool.Generate Start                     */
/*********************************************************************/

#ifndef __DCMEXT_GENERATE_C__
#define __DCMEXT_GENERATE_C__

#include "DcmExt.h"
#include "DcmExt_Generate.h"

#define E_OK		(0u)

/****************************************************************************/
/*                      !!! Don't Remove This Comment !!!                   */
/*                              User's Code Start                           */
/****************************************************************************/
//22 Read data
static uint8 l_F193_HardWare_Version[4] = {0x00, 0x00, 0x00, 0xA1};
static uint8 l_F195_SoftWare_Version[4] = {0x22, 0x06, 0x24, 0x02};

/****************************************************************************/
/*                        !!! Don't Remove This Comment !!!                 */
/*                                User's Code end                           */
/****************************************************************************/

#ifdef SERVICE_22_SUPPORTED
#endif

#ifdef SERVICE_2E_SUPPORTED
#endif

#ifdef SERVICE_2F_SUPPORTED
#endif

#ifdef SERVICE_31_SUPPORTED
#endif


#endif
/*********************************************************************/
/*                       DiagTool.Generate Stop                      */
/*********************************************************************/

