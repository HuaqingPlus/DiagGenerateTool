/*********************************************************************/
/*                       DiagTool.Generate Start                     */
/*********************************************************************/

#ifndef __DCMEXT_GENERATE_H__
#define __DCMEXT_GENERATE_H__

#include "Std_Types.h"

#define DID_0x2FDID_SIZE_2		 ((uint8)2)
#define DR_TIME_NOT_REQ		 ((uint32)0)
#define ROUTINE_TYPE_1		(0x01u)
#define ROUTINE_TYPE_2		(0x02u)
#define RC_STOP_SERVICE		(0x04u)
#define RC_SELFTEST		(0x10u)
#define NO_SPACE_AVAILABLE		(0xFF)
#define LHVSD_CHECK_NEEDED		(0xFF)
#define LHVSD_CHECK_NOT_NEEDED		(0x00)


//PID Define

#ifndef DCM_TABLE_READ
#define DCM_TABLE_READ \

#endif

#ifndef DCM_TABLE_WRITE
#define DCM_TABLE_WRITE \

#endif

#ifndef DCM_TABLE_IOCTRL
#define DCM_TABLE_IOCTRL \

#endif

#ifdef SERVICE_22_SUPPORTED
static const PID_RECORD diag_pid_table_rom[] = 
{
	DCM_TABLE_READ
	{0,NULL_PTR}
}; 
#endif

#ifdef SERVICE_2E_SUPPORTED
static const PID_RECORD diag_write_pid_table_rom[] = 
{
	DCM_TABLE_WRITE
	{0,NULL_PTR}
}; 
#endif

#ifdef SERVICE_2F_SUPPORTED
static const IOCTL_RECORD ioctl_diag_table_rom[] = 
{
	DCM_TABLE_IOCTRL
	{0, 0, 0, NULL_PTR, NULL_PTR, NULL_PTR}
}; 
#endif

//RID Define

#ifndef DCM_TABLE_ROUTINE_CONTROL
#define DCM_TABLE_ROUTINE_CONTROL		\

#endif

#ifdef SERVICE_31_SUPPORTED
static RTN_CTRL_RECORD diag_routine_ctrl_table_rom[] = 
{
	DCM_TABLE_ROUTINE_CONTROL
	{0, 0, 0, 0, 0, 0, 0, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR}
}; 
#endif


#endif
/*********************************************************************/
/*                       DiagTool.Generate Stop                      */
/*********************************************************************/

